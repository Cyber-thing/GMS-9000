import { DOOR_COLORS, PALETTE, TILE_SIZE } from './config';
import {
  BUTTON_DEFS,
  DOOR_DEFS,
  LEVEL_CHECKPOINT,
  LEVEL_EXIT,
  NEON_SIGNS,
  WINDOW_ZONES,
} from './levelData';

interface SkyBuilding {
  x: number;
  w: number;
  h: number;
  accent: string;
}

const SKY_BUILDINGS: SkyBuilding[] = [
  { x: 20, w: 38, h: 120, accent: '#ff2a85' },
  { x: 64, w: 28, h: 86, accent: '#00f0ff' },
  { x: 98, w: 48, h: 145, accent: '#39ff14' },
  { x: 152, w: 34, h: 102, accent: '#ff9500' },
  { x: 194, w: 54, h: 160, accent: '#00f0ff' },
  { x: 256, w: 30, h: 92, accent: '#ff2a85' },
  { x: 292, w: 44, h: 132, accent: '#00f0ff' },
  { x: 344, w: 36, h: 110, accent: '#ff9500' },
  { x: 388, w: 52, h: 152, accent: '#ff2a85' },
  { x: 448, w: 40, h: 118, accent: '#39ff14' },
  { x: 496, w: 46, h: 140, accent: '#00f0ff' },
  { x: 550, w: 32, h: 95, accent: '#ff2a85' },
];

export class BackgroundRenderer {
  public renderBackdrop(
    ctx: CanvasRenderingContext2D,
    camX: number,
    camY: number,
    viewW: number,
    viewH: number,
    time: number
  ): void {
    // Deep interior obsidian wall base with subtle horizontal steel panel seams
    ctx.fillStyle = PALETTE.bgDeep;
    ctx.fillRect(0, 0, viewW, viewH);
    const seamStep = 32;
    const startSeamY = -Math.floor(camY % seamStep);
    ctx.fillStyle = '#0a0d1a';
    for (let y = startSeamY; y < viewH; y += seamStep) {
      ctx.fillRect(0, Math.round(y), viewW, 1);
    }

    // Subtle vertical metal bunker ribs with rivets
    const ribSpacing = 48;
    const firstRib = -Math.floor(camX % ribSpacing);
    for (let x = firstRib; x < viewW; x += ribSpacing) {
      const rx = Math.round(x);
      ctx.fillStyle = '#0b0e1d';
      ctx.fillRect(rx, 0, 10, viewH);
      ctx.fillStyle = '#131830';
      ctx.fillRect(rx + 2, 0, 2, viewH);
      ctx.fillStyle = '#1a2140';
      ctx.fillRect(rx + 6, 0, 1, viewH);
    }

    // Horizontal industrial pipes & hanging braided cables along each floor ceiling
    const pipeRows = [2, 13, 26];
    for (let i = 0; i < pipeRows.length; i++) {
      const py = Math.round(pipeRows[i] * TILE_SIZE - camY + 3);
      if (py < -20 || py > viewH + 20) continue;
      ctx.fillStyle = '#141930';
      ctx.fillRect(0, py, viewW, 7);
      ctx.fillStyle = '#252e52';
      ctx.fillRect(0, py + 1, viewW, 2);
      ctx.fillStyle = '#090b16';
      ctx.fillRect(0, py + 5, viewW, 2);
      // Pipe joints & hanging cable loops
      const jointStep = 64;
      const startJ = -Math.floor(camX % jointStep);
      for (let jx = startJ; jx < viewW; jx += jointStep) {
        const rjx = Math.round(jx);
        ctx.fillStyle = '#36416e';
        ctx.fillRect(rjx, py - 1, 5, 9);
        ctx.fillStyle = '#0d1124';
        ctx.fillRect(rjx + 12, py + 7, 1, 5);
        ctx.fillRect(rjx + 13, py + 11, 14, 1);
        ctx.fillRect(rjx + 27, py + 7, 1, 5);
      }
    }

    // Parallax city skyline inside large corporate windows
    for (let i = 0; i < WINDOW_ZONES.length; i++) {
      const wz = WINDOW_ZONES[i];
      const wx = Math.round(wz.col * TILE_SIZE - camX);
      const wy = Math.round(wz.row * TILE_SIZE - camY);
      const ww = wz.wCols * TILE_SIZE;
      const wh = wz.hRows * TILE_SIZE;

      if (wx + ww < 0 || wx > viewW || wy + wh < 0 || wy > viewH) continue;

      ctx.save();
      ctx.beginPath();
      ctx.rect(wx, wy, ww, wh);
      ctx.clip();

      // Night sky gradient bands
      ctx.fillStyle = '#050712';
      ctx.fillRect(wx, wy, ww, wh);
      ctx.fillStyle = '#0d0924';
      ctx.fillRect(wx, wy + Math.round(wh * 0.35), ww, Math.round(wh * 0.65));
      ctx.fillStyle = '#180c30';
      ctx.fillRect(wx, wy + Math.round(wh * 0.7), ww, Math.round(wh * 0.3));

      // Far skyline silhouettes (0.14x parallax)
      const farOffset = camX * 0.14;
      ctx.fillStyle = '#090d1f';
      for (let b = 0; b < SKY_BUILDINGS.length; b++) {
        const bld = SKY_BUILDINGS[b];
        const bx = Math.round(wx + ((bld.x * 1.2 - farOffset * 0.5 + 650) % 650) - 50);
        const by = wy + wh - Math.min(wh - 3, Math.round(bld.h * 0.72));
        ctx.fillRect(bx, by, bld.w + 8, wy + wh - by);
      }

      // Midground skyscrapers (0.28x camera speed) with antennas & lit windows
      const pxOffset = camX * 0.28;
      for (let b = 0; b < SKY_BUILDINGS.length; b++) {
        const bld = SKY_BUILDINGS[b];
        const bx = Math.round(wx + ((bld.x - pxOffset * 0.4 + 600) % 600) - 60);
        const by = wy + wh - Math.min(wh - 8, Math.round(bld.h * 0.55));
        if (bx + bld.w < wx || bx > wx + ww) continue;

        ctx.fillStyle = '#0e1329';
        ctx.fillRect(bx, by, bld.w, wy + wh - by);
        ctx.fillStyle = '#141b38';
        ctx.fillRect(bx + 2, by + 2, bld.w - 4, 4);

        // Roof antenna + blinking beacon
        ctx.fillStyle = '#253059';
        ctx.fillRect(bx + (bld.w >> 1), by - 8, 1, 8);
        if (Math.floor(time * 2 + b) % 2 === 0) {
          ctx.fillStyle = bld.accent;
          ctx.fillRect(bx + (bld.w >> 1), by - 9, 2, 2);
        }

        // Neon roof strip
        ctx.fillStyle = bld.accent;
        ctx.fillRect(bx + 2, by, bld.w - 4, 2);

        // Lit pixel apartment windows
        ctx.fillStyle = b % 2 === 0 ? '#ffd166' : '#64dfdf';
        for (let ly = by + 8; ly < wy + wh - 4; ly += 5) {
          for (let lx = bx + 4; lx < bx + bld.w - 5; lx += 5) {
            if (((lx + ly + b) % 7) !== 0) {
              ctx.fillRect(lx, ly, 2, 3);
            }
          }
        }
      }

      // Flying traffic light streaks
      const carX = wx + ((Math.floor(time * 75 + i * 90) % (ww + 40)) - 20);
      ctx.fillStyle = PALETTE.neonRed;
      ctx.fillRect(carX, wy + 18, 7, 1);
      ctx.fillStyle = PALETTE.neonCyan;
      ctx.fillRect(wx + ww - (carX - wx), wy + 30, 7, 1);

      // Rain streaks outside window
      ctx.fillStyle = 'rgba(130, 220, 255, 0.32)';
      for (let r = 0; r < 22; r++) {
        const rx = wx + ((r * 23 + Math.floor(time * 40)) % ww);
        const ry = wy + ((r * 19 + Math.floor(time * 180)) % wh);
        ctx.fillRect(rx, ry, 1, 5);
      }

      ctx.restore();

      // Window steel mullions & bolted frame
      ctx.strokeStyle = PALETTE.steelMid;
      ctx.lineWidth = 2;
      ctx.strokeRect(wx + 1, wy + 1, ww - 2, wh - 2);
      ctx.fillStyle = PALETTE.steelDark;
      for (let mx = wx + 48; mx < wx + ww - 8; mx += 48) {
        ctx.fillRect(mx, wy, 3, wh);
      }
    }

    // Server racks & holo-screens scattered on floors
    this.renderServerRacks(ctx, camX, camY, viewW, time);

    // Wall grilles & diegetic directional arrows
    this.renderIndustrialDetails(ctx, camX, camY, viewW, time);

    // Color-coded conduit cables linking buttons & doors
    this.renderConduits(ctx, camX, camY, time);

    // Neon signs
    this.renderNeonSigns(ctx, camX, camY, time);
  }

  private renderIndustrialDetails(
    ctx: CanvasRenderingContext2D,
    camX: number,
    camY: number,
    viewW: number,
    time: number
  ): void {
    // Wall ventilation grilles with dark framing
    const vents = [
      { col: 7, row: 39 },
      { col: 36, row: 39 },
      { col: 78, row: 39 },
      { col: 18, row: 20 },
      { col: 54, row: 20 },
      { col: 32, row: 8 },
      { col: 92, row: 8 },
    ];
    for (let i = 0; i < vents.length; i++) {
      const vx = Math.round(vents[i].col * TILE_SIZE - camX);
      const vy = Math.round(vents[i].row * TILE_SIZE - camY);
      if (vx + 24 < 0 || vx > viewW) continue;
      ctx.fillStyle = '#1f2642';
      ctx.fillRect(vx - 1, vy - 1, 24, 16);
      ctx.fillStyle = '#090c18';
      ctx.fillRect(vx, vy, 22, 14);
      ctx.fillStyle = '#252d4f';
      for (let s = 2; s < 12; s += 3) {
        ctx.fillRect(vx + 2, vy + s, 18, 1);
      }
    }

    // Diegetic glowing navigation chevrons
    const arrows: Array<{ col: number; row: number; dir: 1 | -1; color: string }> = [
      { col: 9, row: 40, dir: 1, color: PALETTE.neonCyan },
      { col: 109, row: 39, dir: 1, color: PALETTE.neonRed },
      { col: 96, row: 34, dir: -1, color: PALETTE.neonRed },
      { col: 26, row: 21, dir: -1, color: '#00d4ff' },
      { col: 74, row: 21, dir: 1, color: '#00d4ff' },
      { col: 92, row: 9, dir: -1, color: PALETTE.neonGreen },
    ];
    const pulse = 0.45 + 0.45 * Math.sin(time * 4.5);
    ctx.save();
    ctx.globalAlpha = pulse;
    for (let i = 0; i < arrows.length; i++) {
      const a = arrows[i];
      const ax = Math.round(a.col * TILE_SIZE - camX);
      const ay = Math.round(a.row * TILE_SIZE - camY);
      if (ax + 20 < 0 || ax > viewW) continue;
      ctx.fillStyle = a.color;
      for (let k = 0; k < 3; k++) {
        const ox = ax + k * 5 * a.dir;
        ctx.fillRect(ox, ay, 2, 2);
        ctx.fillRect(ox + a.dir, ay + 2, 2, 2);
        ctx.fillRect(ox, ay + 4, 2, 2);
      }
    }
    ctx.restore();
  }

  private renderServerRacks(
    ctx: CanvasRenderingContext2D,
    camX: number,
    camY: number,
    viewW: number,
    time: number
  ): void {
    const racks = [
      { col: 15, row: 42 },
      { col: 48, row: 42 },
      { col: 88, row: 42 },
      { col: 28, row: 36 },
      { col: 70, row: 36 },
      { col: 10, row: 23 },
      { col: 44, row: 23 },
      { col: 78, row: 23 },
      { col: 40, row: 11 },
      { col: 80, row: 11 },
    ];
    for (let i = 0; i < racks.length; i++) {
      const rx = Math.round(racks[i].col * TILE_SIZE - camX);
      const ry = Math.round(racks[i].row * TILE_SIZE - 40 - camY);
      if (rx + 22 < 0 || rx > viewW) continue;
      ctx.fillStyle = '#111528';
      ctx.fillRect(rx, ry, 20, 40);
      ctx.fillStyle = '#1d2442';
      ctx.fillRect(rx + 2, ry + 2, 16, 36);
      for (let row = 0; row < 6; row++) {
        ctx.fillStyle = '#090b15';
        ctx.fillRect(rx + 3, ry + 4 + row * 5, 14, 3);
        const blink = ((Math.floor(time * 4 + i + row) + i * 3) % 5) === 0;
        ctx.fillStyle = blink ? PALETTE.neonCyan : row % 2 === 0 ? PALETTE.neonGreen : '#1e3a4c';
        ctx.fillRect(rx + 5, ry + 5 + row * 5, 2, 1);
        ctx.fillStyle = row === 2 ? PALETTE.neonPink : '#1a2f3d';
        ctx.fillRect(rx + 9, ry + 5 + row * 5, 2, 1);
      }
    }
  }

  private renderConduits(ctx: CanvasRenderingContext2D, camX: number, camY: number, time: number): void {
    const pulse = 0.45 + 0.35 * Math.sin(time * 5);
    ctx.save();
    ctx.globalAlpha = pulse;
    for (let i = 0; i < DOOR_DEFS.length; i++) {
      const d = DOOR_DEFS[i];
      const b = BUTTON_DEFS.find((btn) => btn.color === d.color);
      if (!b) continue;
      const c = DOOR_COLORS[d.color].main;
      const dx = Math.round(d.col * TILE_SIZE + 8 - camX);
      const dy = Math.round(d.topRow * TILE_SIZE - 4 - camY);
      const bx = Math.round(b.col * TILE_SIZE + 8 - camX);
      const by = Math.round(b.row * TILE_SIZE - 4 - camY);
      ctx.strokeStyle = c;
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(bx, by);
      ctx.lineTo(bx, dy - 6);
      ctx.lineTo(dx, dy - 6);
      ctx.lineTo(dx, dy);
      ctx.stroke();
    }
    ctx.restore();
  }

  private renderNeonSigns(ctx: CanvasRenderingContext2D, camX: number, camY: number, time: number): void {
    ctx.font = 'bold 7px "JetBrains Mono", monospace';
    ctx.textBaseline = 'top';
    for (let i = 0; i < NEON_SIGNS.length; i++) {
      const s = NEON_SIGNS[i];
      const sx = Math.round(s.col * TILE_SIZE - camX);
      const sy = Math.round(s.row * TILE_SIZE - camY);
      const flicker = Math.sin(time * 19 + i * 7.3) > -0.92 ? 1 : 0.25;
      const tw = s.text.length * 5 + 8;

      ctx.fillStyle = '#090c17';
      ctx.fillRect(sx, sy, tw, 13);
      ctx.strokeStyle = s.color;
      ctx.globalAlpha = flicker;
      ctx.lineWidth = 1;
      ctx.strokeRect(sx + 0.5, sy + 0.5, tw - 1, 12);
      ctx.fillStyle = s.color;
      ctx.fillText(s.text, sx + 4, sy + 3);
      ctx.globalAlpha = 1;
    }
  }

  public renderSpecialStations(
    ctx: CanvasRenderingContext2D,
    camX: number,
    camY: number,
    time: number,
    checkpointSaved: boolean
  ): void {
    // Checkpoint Terminal on Floor 2
    const cx = Math.round(LEVEL_CHECKPOINT.col * TILE_SIZE - camX);
    const cy = Math.round(LEVEL_CHECKPOINT.row * TILE_SIZE - 26 - camY);
    ctx.fillStyle = PALETTE.steelMid;
    ctx.fillRect(cx, cy + 8, 18, 18);
    ctx.fillStyle = '#0a0e1b';
    ctx.fillRect(cx + 2, cy, 14, 14);
    ctx.fillStyle = checkpointSaved ? PALETTE.neonGreen : PALETTE.neonAmber;
    ctx.fillRect(cx + 4, cy + 2, 10, 8);
    ctx.fillStyle = PALETTE.white;
    ctx.fillRect(cx + 6, cy + 4, 6, 2);

    // Extraction Exit Airlock on Floor 3
    const ex = Math.round(LEVEL_EXIT.col * TILE_SIZE - 8 - camX);
    const ey = Math.round(LEVEL_EXIT.row * TILE_SIZE - 42 - camY);
    ctx.fillStyle = '#182238';
    ctx.fillRect(ex, ey, 34, 42);
    ctx.fillStyle = PALETTE.steelLight;
    ctx.fillRect(ex, ey, 34, 3);
    ctx.fillRect(ex, ey, 3, 42);
    ctx.fillRect(ex + 31, ey, 3, 42);

    const glow = 0.65 + 0.35 * Math.sin(time * 5);
    ctx.globalAlpha = glow;
    ctx.fillStyle = PALETTE.neonGreen;
    ctx.fillRect(ex + 5, ey + 5, 24, 37);
    ctx.fillStyle = '#071c12';
    ctx.fillRect(ex + 8, ey + 8, 18, 34);
    ctx.fillStyle = PALETTE.neonGreen;
    ctx.fillRect(ex + 12, ey + 14, 10, 3);
    ctx.globalAlpha = 1;
  }

  public renderAdditiveGlow(
    ctx: CanvasRenderingContext2D,
    camX: number,
    camY: number,
    time: number
  ): void {
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    for (let i = 0; i < NEON_SIGNS.length; i++) {
      const s = NEON_SIGNS[i];
      const tw = s.text.length * 5 + 8;
      const sx = Math.round(s.col * TILE_SIZE - camX + tw * 0.5);
      const sy = Math.round(s.row * TILE_SIZE - camY + 6);
      const flicker = Math.sin(time * 19 + i * 7.3) > -0.92 ? 0.1 : 0.02;
      ctx.globalAlpha = flicker;
      ctx.fillStyle = s.color;
      ctx.fillRect(sx - (tw >> 1) - 4, sy - 8, tw + 8, 16);
    }
    ctx.restore();
  }
}
