export type GamePhase = 'title' | 'playing' | 'paused' | 'victory' | 'defeat';

export type WeaponId = 'pistol' | 'shotgun' | 'smg';

export type DoorColor = 'red' | 'blue' | 'green';

export type EnemyKind = 'thug' | 'heavy' | 'drone' | 'turret';

export type EnemyAIState = 'patrol' | 'alert' | 'attack' | 'retreat' | 'dead';

export type PropKind = 'crate' | 'monitor' | 'barrel';

export type PickupKind = 'health' | 'shotgun' | 'smg' | 'ammo';

export type AimMode = 'straight' | 'upDiag' | 'up' | 'downDiag' | 'down';

export interface WeaponConfig {
  id: WeaponId;
  name: string;
  shortName: string;
  fireRate: number;
  damage: number;
  bulletSpeed: number;
  pellets: number;
  spreadRad: number;
  knockback: number;
  muzzleColor: string;
  bulletColor: string;
  recoil: number;
  maxAmmo: number;
  auto: boolean;
}

export interface Rect {
  x: number;
  y: number;
  w: number;
  h: number;
}

export interface InputSnapshot {
  left: boolean;
  right: boolean;
  up: boolean;
  down: boolean;
  jumpHeld: boolean;
  jumpPressed: boolean;
  shootHeld: boolean;
  shootPressed: boolean;
  dashPressed: boolean;
  interactPressed: boolean;
  cycleWeaponPressed: boolean;
  selectWeapon: WeaponId | null;
}

export interface DoorStatusHud {
  color: DoorColor;
  isOpen: boolean;
  timerRemaining: number | null;
  timerTotal: number | null;
}

export interface HudSnapshot {
  phase: GamePhase;
  hp: number;
  maxHp: number;
  weapon: WeaponId;
  unlockedWeapons: WeaponId[];
  ammo: Record<WeaponId, number>;
  kills: number;
  totalEnemies: number;
  propsDestroyed: number;
  elapsedTime: number;
  damageTaken: number;
  checkpointSaved: boolean;
  doors: DoorStatusHud[];
  promptText: string | null;
  bannerText: string | null;
  crtEnabled: boolean;
  muted: boolean;
  floorNumber: 1 | 2 | 3;
}
