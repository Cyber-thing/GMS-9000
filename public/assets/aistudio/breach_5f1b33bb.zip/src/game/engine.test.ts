import test from 'node:test';
import assert from 'node:assert/strict';
import { PHYSICS, TILE_SIZE } from './config';
import { Door, Elevator } from './entities';
import { GangThug } from './enemies';
import { GameEngine } from './engine';
import {
  DOOR_DEFS,
  ELEVATOR_DEFS,
  LEVEL_ASCII,
  LEVEL_SPAWN,
} from './levelData';
import { Tilemap } from './tilemap';
import type { InputSnapshot } from './types';

function emptyInput(overrides: Partial<InputSnapshot> = {}): InputSnapshot {
  return {
    left: false,
    right: false,
    up: false,
    down: false,
    jumpHeld: false,
    jumpPressed: false,
    shootHeld: false,
    shootPressed: false,
    dashPressed: false,
    interactPressed: false,
    cycleWeaponPressed: false,
    selectWeapon: null,
    ...overrides,
  };
}

test('tilemap spawn area is open and floor beneath spawn is solid', () => {
  const tm = new Tilemap(LEVEL_ASCII);
  assert.equal(tm.getTile(LEVEL_SPAWN.col, LEVEL_SPAWN.row), 'solid');
  for (let c = LEVEL_SPAWN.col; c < LEVEL_SPAWN.col + 6; c++) {
    assert.equal(tm.getTile(c, LEVEL_SPAWN.row - 1), 'empty');
    assert.equal(tm.getTile(c, LEVEL_SPAWN.row - 2), 'empty');
  }
});

test('tilemap one-way platform supports landing from above and allows jumping from below', () => {
  const tm = new Tilemap([
    '..........',
    '..........',
    '..======..',
    '..........',
    '##########',
  ]);

  // Falling onto row 2 from above
  const falling = { x: 48, y: 16, w: 14, h: 16 }; // bottom = 32, row 2 top = 32
  const resLand = tm.moveAndCollide(falling, 0, 120, 1 / 60);
  assert.equal(resLand.hitBottom, true);
  assert.equal(resLand.onOneWay, true);
  assert.equal(falling.y + falling.h, 32);

  // Jumping UP through row 2 from below
  const rising = { x: 48, y: 34, w: 14, h: 16 };
  const resRise = tm.moveAndCollide(rising, 0, -240, 1 / 60);
  assert.equal(resRise.hitTop, false);
  assert.ok(rising.y < 34);
});

test('crouching lowers player hitbox and dodges chest-height Gang Thug bullets', () => {
  const engine = new GameEngine();
  engine.startNewRun();
  const floorY = LEVEL_SPAWN.row * TILE_SIZE;
  const thug = new GangThug({
    kind: 'thug',
    col: 10,
    row: LEVEL_SPAWN.row,
    facing: -1,
    patrolMinCol: 8,
    patrolMaxCol: 14,
  });

  // Thug fires at y = thug.y + 6 = floorY - 26 + 6 = floorY - 20
  const bulletY = thug.y + 6;
  const standTop = floorY - PHYSICS.playerStandH; // floorY - 28
  const crouchTop = floorY - PHYSICS.playerCrouchH; // floorY - 17

  assert.ok(bulletY > standTop && bulletY < floorY, 'bullet hits standing player');
  assert.ok(bulletY + 2 < crouchTop, 'bullet clears crouching player head');

  // Verify Player.setCrouching preserves bottom feet position
  const prevBottom = engine.player.y + engine.player.h;
  engine.player.setCrouching(true, engine.tilemap);
  assert.equal(engine.player.crouching, true);
  assert.equal(engine.player.h, PHYSICS.playerCrouchH);
  assert.equal(engine.player.y + engine.player.h, prevBottom);
});

test('closed doors block movement and timed green door counts down to close', () => {
  const redDoor = new Door(DOOR_DEFS.find((d) => d.color === 'red')!);
  assert.equal(redDoor.isBlocking(), true);
  assert.ok(redDoor.getSolidRect() !== null);

  redDoor.open();
  for (let i = 0; i < 40; i++) {
    redDoor.update(1 / 60, { x: 0, y: 0, w: 14, h: 28 });
  }
  assert.equal(redDoor.isOpen, true);
  assert.equal(redDoor.isBlocking(), false);
  assert.equal(redDoor.getSolidRect(), null);

  const greenDoor = new Door(DOOR_DEFS.find((d) => d.color === 'green')!);
  greenDoor.open();
  assert.equal(greenDoor.isOpen, true);
  assert.equal(greenDoor.timerRemaining, 15);
  // Advance 16 seconds with player far away -> door closes again
  for (let i = 0; i < 16 * 60; i++) {
    greenDoor.update(1 / 60, { x: 0, y: 0, w: 14, h: 28 });
  }
  assert.equal(greenDoor.isOpen, false);
  assert.equal(greenDoor.isBlocking(), true);
});

test('elevator moves smoothly between stops and carries player upward', () => {
  const elev = new Elevator(ELEVATOR_DEFS[0]);
  const startY = elev.y;
  assert.equal(startY, elev.bottomY);
  assert.ok(elev.topY < elev.bottomY);

  const playerRect = {
    x: elev.x + 8,
    y: elev.y - PHYSICS.playerStandH,
    w: PHYSICS.playerStandW,
    h: PHYSICS.playerStandH,
  };
  assert.equal(elev.isPlayerOnTop(playerRect), true);

  // Trigger elevator via dwell and advance until it reaches topY
  for (let i = 0; i < 300; i++) {
    const onTop = elev.isPlayerOnTop(playerRect);
    const dy = elev.update(1 / 60, onTop);
    if (onTop) playerRect.y += dy;
  }

  assert.equal(elev.y, elev.topY);
  assert.equal(playerRect.y + playerRect.h, elev.topY);
});

test('enemy AI transitions from patrol -> alert -> attack -> dead and drops or awards kill', () => {
  const tm = new Tilemap(LEVEL_ASCII);
  const thug = new GangThug({
    kind: 'thug',
    col: 20,
    row: LEVEL_SPAWN.row,
    facing: -1,
    patrolMinCol: 15,
    patrolMaxCol: 25,
  });

  // Player in clear line of sight to the left
  const playerRect = {
    x: 14 * TILE_SIZE,
    y: LEVEL_SPAWN.row * TILE_SIZE - 28,
    w: 14,
    h: 28,
  };

  let shotsFired = 0;
  for (let i = 0; i < 45; i++) {
    thug.updateAI(1 / 60, playerRect, tm, [], (bullets) => {
      shotsFired += bullets.length;
    });
  }
  assert.ok(thug.state === 'alert' || thug.state === 'attack' || thug.state === 'retreat');
  assert.ok(shotsFired >= 1, 'enemy should fire after alert telegraph');

  // Lethal damage triggers dead state and removal after KO timer
  const killed = thug.takeDamage(10, 120);
  assert.equal(killed, true);
  assert.equal(thug.state, 'dead');
  for (let i = 0; i < 30; i++) {
    thug.updateAI(1 / 60, playerRect, tm, [], () => {});
  }
  assert.equal(thug.removed, true);
});

test('player survives idle at start and coyote time allows jump shortly after stepping off ledge', () => {
  const engine = new GameEngine();
  engine.startNewRun();
  for (let i = 0; i < 180; i++) {
    engine.stepSimulation(1 / 60);
  }
  assert.equal(engine.phase, 'playing');
  assert.equal(engine.player.hp, PHYSICS.playerMaxHp);

  // Simulate stepping off ledge (grounded -> false, coyoteTimer > 0) then jumping
  engine.player.grounded = false;
  engine.player.coyoteTimer = 0.08;
  engine.player.update(
    1 / 60,
    emptyInput({ jumpPressed: true, jumpHeld: true }),
    engine.tilemap,
    [],
    {
      onJump: () => {},
      onLand: () => {},
      onDash: () => {},
      onShoot: () => {},
    }
  );
  assert.ok(engine.player.vy < -200, 'coyote jump should launch player upward');
});

test('angled aiming and 6-frame animation state transitions work accurately', () => {
  const engine = new GameEngine();
  engine.startNewRun();

  // Idle -> Run
  for (let i = 0; i < 12; i++) {
    engine.player.update(
      1 / 60,
      emptyInput({ right: true, up: true }),
      engine.tilemap,
      [],
      { onJump: () => {}, onLand: () => {}, onDash: () => {}, onShoot: () => {} }
    );
  }
  assert.equal(engine.player.aimMode, 'upDiag');
  assert.equal(engine.player.animState, 'run');
  assert.ok(Math.abs(engine.player.getAimAngleRad() - (-Math.PI / 4)) < 0.01);

  // Straight Up aim
  engine.player.update(
    1 / 60,
    emptyInput({ up: true }),
    engine.tilemap,
    [],
    { onJump: () => {}, onLand: () => {}, onDash: () => {}, onShoot: () => {} }
  );
  assert.equal(engine.player.aimMode, 'up');
  assert.ok(Math.abs(engine.player.getAimAngleRad() - (-Math.PI / 2)) < 0.01);

  // Crouch
  engine.player.update(
    1 / 60,
    emptyInput({ down: true }),
    engine.tilemap,
    [],
    { onJump: () => {}, onLand: () => {}, onDash: () => {}, onShoot: () => {} }
  );
  assert.equal(engine.player.animState, 'crouch');
  assert.equal(engine.player.crouching, true);

  // Airborne diagonal down aim (after jumping)
  engine.player.update(
    1 / 60,
    emptyInput({ jumpPressed: true, jumpHeld: true, down: true, right: true }),
    engine.tilemap,
    [],
    { onJump: () => {}, onLand: () => {}, onDash: () => {}, onShoot: () => {} }
  );
  // Second tick airborne while holding down + right
  engine.player.update(
    1 / 60,
    emptyInput({ jumpHeld: true, down: true, right: true }),
    engine.tilemap,
    [],
    { onJump: () => {}, onLand: () => {}, onDash: () => {}, onShoot: () => {} }
  );
  assert.equal(engine.player.animState, 'jump');
  assert.equal(engine.player.aimMode, 'downDiag');
  assert.ok(Math.abs(engine.player.getAimAngleRad() - (Math.PI / 4)) < 0.01);
});
