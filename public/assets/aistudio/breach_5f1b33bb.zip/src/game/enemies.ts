import { PALETTE, PHYSICS, TILE_SIZE } from './config';
import { Bullet } from './entities';
import type { EnemySpawnDef } from './levelData';
import { renderDroneSprite, renderHeavySprite, renderThugSprite } from './sprites';
import type { Tilemap } from './tilemap';
import type { EnemyAIState, EnemyKind, PickupKind, Rect } from './types';

export abstract class Enemy {
  public readonly kind: EnemyKind;
  public x: number;
  public y: number;
  public w: number;
  public h: number;
  public vx = 0;
  public vy = 0;
  public facing: 1 | -1;

  public hp: number;
  public maxHp: number;
  public state: EnemyAIState = 'patrol';
  public stateTimer = 0;
  public patrolMinX: number;
  public patrolMaxX: number;
  public hitFlashTimer = 0;
  public deadTimer = 0;
  public removed = false;
  public dropSpawned = false;
  public animTime = 0;

  protected readonly baseY: number;

  constructor(def: EnemySpawnDef, w: number, h: number, hp: number) {
    this.kind = def.kind;
    this.w = w;
    this.h = h;
    this.hp = hp;
    this.maxHp = hp;
    this.facing = def.facing;
    this.x = def.col * TILE_SIZE;
    this.y = def.kind === 'turret' ? def.row * TILE_SIZE : def.row * TILE_SIZE - h;
    this.baseY = this.y;
    this.patrolMinX = def.patrolMinCol * TILE_SIZE;
    this.patrolMaxX = def.patrolMaxCol * TILE_SIZE;
    this.animTime = Math.random() * 10;
  }

  public getRect(): Rect {
    return { x: this.x, y: this.y, w: this.w, h: this.h };
  }

  public isAlive(): boolean {
    return this.state !== 'dead';
  }

  public takeDamage(damage: number, knockX: number): boolean {
    if (this.state === 'dead') return false;
    this.hp -= damage;
    this.hitFlashTimer = 0.065;
    if (this.kind !== 'turret') {
      this.vx += knockX;
    }
    if (this.state === 'patrol') {
      this.state = 'alert';
      this.stateTimer = 0.25;
      if (knockX !== 0) {
        this.facing = knockX > 0 ? -1 : 1;
      }
    }
    if (this.hp <= 0) {
      this.hp = 0;
      this.state = 'dead';
      this.deadTimer = 0.32;
      if (this.kind !== 'turret') {
        this.vy = -110;
      }
      return true;
    }
    return false;
  }

  public rollDrop(): PickupKind | null {
    const r = Math.random();
    if (r < 0.24) return 'health';
    if (r < 0.52) return 'ammo';
    return null;
  }

  public abstract updateAI(
    dt: number,
    playerRect: Rect,
    tilemap: Tilemap,
    blockingRects: Rect[],
    onShoot: (bullets: Bullet[]) => void
  ): void;

  public abstract render(ctx: CanvasRenderingContext2D, camX: number, camY: number): void;

  protected renderTelegraph(ctx: CanvasRenderingContext2D, sx: number, sy: number, color: string): void {
    if (this.state !== 'alert') return;
    ctx.fillStyle = color;
    // Pixel exclamation mark above head
    ctx.fillRect(sx + (this.w >> 1) - 1, sy - 11, 2, 5);
    ctx.fillRect(sx + (this.w >> 1) - 1, sy - 4, 2, 2);
  }
}

export class GangThug extends Enemy {
  private burstLeft = 0;
  private burstCd = 0;

  constructor(def: EnemySpawnDef) {
    super(def, 14, 26, 3);
  }

  public updateAI(
    dt: number,
    playerRect: Rect,
    tilemap: Tilemap,
    blockingRects: Rect[],
    onShoot: (bullets: Bullet[]) => void
  ): void {
    this.animTime += dt;
    if (this.hitFlashTimer > 0) this.hitFlashTimer -= dt;

    if (this.state === 'dead') {
      this.deadTimer -= dt;
      this.vy = Math.min(PHYSICS.maxFallSpeed, this.vy + PHYSICS.gravity * dt);
      const r = this.getRect();
      tilemap.moveAndCollide(r, this.vx, this.vy, dt, { extraSolids: blockingRects });
      this.x = r.x;
      this.y = r.y;
      this.vx *= 0.9;
      if (this.deadTimer <= 0) this.removed = true;
      return;
    }

    const px = playerRect.x + playerRect.w * 0.5;
    const py = playerRect.y + playerRect.h * 0.5;
    const cx = this.x + this.w * 0.5;
    const cy = this.y + 8;
    const dx = px - cx;
    const dy = py - cy;
    const dist = Math.hypot(dx, dy);
    const hasSight =
      dist <= 220 &&
      Math.abs(dy) <= 46 &&
      tilemap.hasLineOfSight(cx, cy, px, py, blockingRects);

    switch (this.state) {
      case 'patrol': {
        const patrolSpeed = 42;
        this.vx = this.facing * patrolSpeed;
        if (this.x <= this.patrolMinX) this.facing = 1;
        if (this.x >= this.patrolMaxX) this.facing = -1;
        if (hasSight && (Math.sign(dx) === this.facing || dist < 110)) {
          this.facing = dx >= 0 ? 1 : -1;
          this.state = 'alert';
          this.stateTimer = 0.36;
          this.vx = 0;
        }
        break;
      }
      case 'alert': {
        this.vx *= 0.85;
        this.facing = dx >= 0 ? 1 : -1;
        this.stateTimer -= dt;
        if (this.stateTimer <= 0) {
          this.state = 'attack';
          this.burstLeft = 2;
          this.burstCd = 0;
          this.stateTimer = 0.55;
        }
        break;
      }
      case 'attack': {
        this.vx *= 0.85;
        this.facing = dx >= 0 ? 1 : -1;
        this.burstCd -= dt;
        if (this.burstLeft > 0 && this.burstCd <= 0) {
          this.burstLeft--;
          this.burstCd = 0.22;
          // Fires at standing chest height (6px below enemy top = 20px above floor) so crouching dodges cleanly
          const bx = this.x + (this.facing === 1 ? this.w + 2 : -2);
          const by = this.y + 6;
          onShoot([
            new Bullet({
              x: bx,
              y: by,
              vx: this.facing * 225,
              vy: 0,
              fromPlayer: false,
              damage: 1,
              knockback: 90,
              color: PALETTE.neonPink,
            }),
          ]);
        }
        this.stateTimer -= dt;
        if (this.stateTimer <= 0) {
          if (dist < 68) {
            this.state = 'retreat';
            this.stateTimer = 0.45;
          } else if (hasSight) {
            this.state = 'alert';
            this.stateTimer = 0.45;
          } else {
            this.state = 'patrol';
          }
        }
        break;
      }
      case 'retreat': {
        const awayDir = dx >= 0 ? -1 : 1;
        this.vx = awayDir * 64;
        this.facing = dx >= 0 ? 1 : -1;
        this.stateTimer -= dt;
        if (this.stateTimer <= 0) {
          this.state = hasSight ? 'alert' : 'patrol';
          this.stateTimer = 0.35;
        }
        break;
      }
    }

    // Clamp patrol zone during patrol/retreat
    if (this.state === 'patrol' || this.state === 'retreat') {
      if (this.x < this.patrolMinX && this.vx < 0) this.vx = 0;
      if (this.x > this.patrolMaxX && this.vx > 0) this.vx = 0;
    }

    this.vy = Math.min(PHYSICS.maxFallSpeed, this.vy + PHYSICS.gravity * dt);
    const rect = this.getRect();
    const col = tilemap.moveAndCollide(rect, this.vx, this.vy, dt, { extraSolids: blockingRects });
    this.x = rect.x;
    this.y = rect.y;
    if (col.hitLeft || col.hitRight) this.facing = this.facing === 1 ? -1 : 1;
    if (col.hitBottom) this.vy = 0;
  }

  public render(ctx: CanvasRenderingContext2D, camX: number, camY: number): void {
    const sx = Math.round(this.x - camX);
    const sy = Math.round(this.y - camY);
    if (this.state === 'dead') {
      ctx.globalAlpha = Math.max(0, this.deadTimer / 0.32);
    }

    const frameIdx = Math.floor(this.animTime * 10) % 6;
    renderThugSprite(
      ctx,
      sx,
      sy,
      this.w,
      this.h,
      this.facing,
      this.state,
      frameIdx,
      this.hitFlashTimer > 0
    );

    this.renderTelegraph(ctx, sx, sy, PALETTE.neonPink);
    ctx.globalAlpha = 1;
  }
}

export class HeavyShotgunner extends Enemy {
  private fired = false;

  constructor(def: EnemySpawnDef) {
    super(def, 18, 30, 6);
  }

  public updateAI(
    dt: number,
    playerRect: Rect,
    tilemap: Tilemap,
    blockingRects: Rect[],
    onShoot: (bullets: Bullet[]) => void
  ): void {
    this.animTime += dt;
    if (this.hitFlashTimer > 0) this.hitFlashTimer -= dt;

    if (this.state === 'dead') {
      this.deadTimer -= dt;
      this.vy = Math.min(PHYSICS.maxFallSpeed, this.vy + PHYSICS.gravity * dt);
      const r = this.getRect();
      tilemap.moveAndCollide(r, this.vx, this.vy, dt, { extraSolids: blockingRects });
      this.x = r.x;
      this.y = r.y;
      this.vx *= 0.9;
      if (this.deadTimer <= 0) this.removed = true;
      return;
    }

    const px = playerRect.x + playerRect.w * 0.5;
    const py = playerRect.y + playerRect.h * 0.5;
    const cx = this.x + this.w * 0.5;
    const cy = this.y + 12;
    const dx = px - cx;
    const dy = py - cy;
    const dist = Math.hypot(dx, dy);
    const hasSight =
      dist <= 200 &&
      Math.abs(dy) <= 44 &&
      tilemap.hasLineOfSight(cx, cy, px, py, blockingRects);

    switch (this.state) {
      case 'patrol': {
        this.vx = this.facing * 28;
        if (this.x <= this.patrolMinX) this.facing = 1;
        if (this.x >= this.patrolMaxX) this.facing = -1;
        if (hasSight) {
          this.facing = dx >= 0 ? 1 : -1;
          this.state = 'alert';
          this.stateTimer = 0.5;
          this.vx = 0;
        }
        break;
      }
      case 'alert': {
        this.vx *= 0.8;
        this.facing = dx >= 0 ? 1 : -1;
        this.stateTimer -= dt;
        if (this.stateTimer <= 0) {
          this.state = 'attack';
          this.fired = false;
          this.stateTimer = 0.45;
        }
        break;
      }
      case 'attack': {
        this.vx *= 0.8;
        if (!this.fired) {
          this.fired = true;
          const bx = this.x + (this.facing === 1 ? this.w + 2 : -2);
          const by = this.y + 11;
          const baseAng = this.facing === 1 ? 0 : Math.PI;
          const spread = [-0.18, 0, 0.18];
          const bullets = spread.map(
            (off) =>
              new Bullet({
                x: bx,
                y: by,
                vx: Math.cos(baseAng + off) * 200,
                vy: Math.sin(baseAng + off) * 200,
                fromPlayer: false,
                damage: 1,
                knockback: 130,
                color: PALETTE.neonAmber,
                size: 5,
              })
          );
          onShoot(bullets);
        }
        this.stateTimer -= dt;
        if (this.stateTimer <= 0) {
          this.state = 'retreat';
          this.stateTimer = 0.85;
        }
        break;
      }
      case 'retreat': {
        // Slowly paces back while pumping shotgun
        const away = dx >= 0 ? -1 : 1;
        this.vx = away * 32;
        this.facing = dx >= 0 ? 1 : -1;
        this.stateTimer -= dt;
        if (this.stateTimer <= 0) {
          this.state = hasSight ? 'alert' : 'patrol';
          this.stateTimer = 0.45;
        }
        break;
      }
    }

    if (this.state === 'patrol' || this.state === 'retreat') {
      if (this.x < this.patrolMinX && this.vx < 0) this.vx = 0;
      if (this.x > this.patrolMaxX && this.vx > 0) this.vx = 0;
    }

    this.vy = Math.min(PHYSICS.maxFallSpeed, this.vy + PHYSICS.gravity * dt);
    const rect = this.getRect();
    const col = tilemap.moveAndCollide(rect, this.vx, this.vy, dt, { extraSolids: blockingRects });
    this.x = rect.x;
    this.y = rect.y;
    if (col.hitLeft || col.hitRight) this.facing = this.facing === 1 ? -1 : 1;
    if (col.hitBottom) this.vy = 0;
  }

  public render(ctx: CanvasRenderingContext2D, camX: number, camY: number): void {
    const sx = Math.round(this.x - camX);
    const sy = Math.round(this.y - camY);
    if (this.state === 'dead') {
      ctx.globalAlpha = Math.max(0, this.deadTimer / 0.32);
    }

    const frameIdx = Math.floor(this.animTime * 8) % 6;
    renderHeavySprite(
      ctx,
      sx,
      sy,
      this.w,
      this.h,
      this.facing,
      this.state,
      frameIdx,
      this.hitFlashTimer > 0
    );

    // Alert laser telegraph
    if (this.state === 'alert') {
      ctx.fillStyle = 'rgba(255, 149, 0, 0.55)';
      const lx = this.facing === 1 ? sx + 18 : sx - 55;
      ctx.fillRect(lx, sy + 12, 55, 1);
    }

    this.renderTelegraph(ctx, sx, sy, PALETTE.neonAmber);
    ctx.globalAlpha = 1;
  }
}

export class SecurityDrone extends Enemy {
  private burstLeft = 0;
  private burstCd = 0;

  constructor(def: EnemySpawnDef) {
    super(def, 16, 14, 3);
  }

  public updateAI(
    dt: number,
    playerRect: Rect,
    tilemap: Tilemap,
    blockingRects: Rect[],
    onShoot: (bullets: Bullet[]) => void
  ): void {
    this.animTime += dt;
    if (this.hitFlashTimer > 0) this.hitFlashTimer -= dt;

    if (this.state === 'dead') {
      this.deadTimer -= dt;
      this.y += 60 * dt;
      if (this.deadTimer <= 0) this.removed = true;
      return;
    }

    const px = playerRect.x + playerRect.w * 0.5;
    const py = playerRect.y + playerRect.h * 0.5;
    const cx = this.x + this.w * 0.5;
    const cy = this.y + this.h * 0.5;
    const dx = px - cx;
    const dy = py - cy;
    const dist = Math.hypot(dx, dy);
    const hasSight = dist <= 235 && tilemap.hasLineOfSight(cx, cy, px, py, blockingRects);

    const hoverY = this.baseY + Math.sin(this.animTime * 3.4) * 7;

    switch (this.state) {
      case 'patrol': {
        this.vx = this.facing * 54;
        this.x += this.vx * dt;
        this.y += (hoverY - this.y) * Math.min(1, 6 * dt);
        if (this.x <= this.patrolMinX) this.facing = 1;
        if (this.x >= this.patrolMaxX) this.facing = -1;
        if (hasSight) {
          this.facing = dx >= 0 ? 1 : -1;
          this.state = 'alert';
          this.stateTimer = 0.4;
        }
        break;
      }
      case 'alert': {
        this.facing = dx >= 0 ? 1 : -1;
        this.y += (hoverY - this.y) * Math.min(1, 6 * dt);
        this.stateTimer -= dt;
        if (this.stateTimer <= 0) {
          this.state = 'attack';
          this.burstLeft = 3;
          this.burstCd = 0;
          this.stateTimer = 0.7;
        }
        break;
      }
      case 'attack': {
        this.facing = dx >= 0 ? 1 : -1;
        this.y += (hoverY - this.y) * Math.min(1, 6 * dt);
        this.burstCd -= dt;
        if (this.burstLeft > 0 && this.burstCd <= 0) {
          this.burstLeft--;
          this.burstCd = 0.14;
          const ang = Math.atan2(dy, dx);
          onShoot([
            new Bullet({
              x: cx,
              y: cy + 2,
              vx: Math.cos(ang) * 215,
              vy: Math.sin(ang) * 215,
              fromPlayer: false,
              damage: 1,
              knockback: 75,
              color: PALETTE.neonCyan,
            }),
          ]);
        }
        this.stateTimer -= dt;
        if (this.stateTimer <= 0) {
          this.state = 'retreat';
          this.stateTimer = 0.75;
        }
        break;
      }
      case 'retreat': {
        const away = dx >= 0 ? -1 : 1;
        this.x += away * 66 * dt;
        this.x = Math.max(this.patrolMinX, Math.min(this.patrolMaxX, this.x));
        this.y += (hoverY - 8 - this.y) * Math.min(1, 5 * dt);
        this.stateTimer -= dt;
        if (this.stateTimer <= 0) {
          this.state = hasSight ? 'alert' : 'patrol';
          this.stateTimer = 0.38;
        }
        break;
      }
    }
  }

  public render(ctx: CanvasRenderingContext2D, camX: number, camY: number): void {
    const sx = Math.round(this.x - camX);
    const sy = Math.round(this.y - camY);
    if (this.state === 'dead') {
      ctx.globalAlpha = Math.max(0, this.deadTimer / 0.32);
    }

    const frameIdx = Math.floor(this.animTime * 16) % 6;
    renderDroneSprite(
      ctx,
      sx,
      sy,
      this.facing,
      this.state,
      frameIdx,
      this.hitFlashTimer > 0
    );

    this.renderTelegraph(ctx, sx, sy, PALETTE.neonCyan);
    ctx.globalAlpha = 1;
  }
}

export class WallTurret extends Enemy {
  private aimAngle = Math.PI / 2;
  private burstLeft = 0;
  private burstCd = 0;

  constructor(def: EnemySpawnDef) {
    super(def, 16, 14, 4);
  }

  public updateAI(
    dt: number,
    playerRect: Rect,
    tilemap: Tilemap,
    blockingRects: Rect[],
    onShoot: (bullets: Bullet[]) => void
  ): void {
    this.animTime += dt;
    if (this.hitFlashTimer > 0) this.hitFlashTimer -= dt;

    if (this.state === 'dead') {
      this.deadTimer -= dt;
      if (this.deadTimer <= 0) this.removed = true;
      return;
    }

    const px = playerRect.x + playerRect.w * 0.5;
    const py = playerRect.y + playerRect.h * 0.5;
    const cx = this.x + this.w * 0.5;
    const cy = this.y + 9;
    const dx = px - cx;
    const dy = py - cy;
    const dist = Math.hypot(dx, dy);
    const hasSight =
      dist <= 240 &&
      dy > -12 &&
      tilemap.hasLineOfSight(cx, cy, px, py, blockingRects);

    switch (this.state) {
      case 'patrol': {
        this.aimAngle = Math.PI / 2 + Math.sin(this.animTime * 2) * 0.65;
        if (hasSight) {
          this.aimAngle = Math.atan2(dy, dx);
          this.state = 'alert';
          this.stateTimer = 0.45;
        }
        break;
      }
      case 'alert': {
        this.aimAngle = Math.atan2(dy, dx);
        this.stateTimer -= dt;
        if (this.stateTimer <= 0) {
          this.state = 'attack';
          this.burstLeft = 3;
          this.burstCd = 0;
          this.stateTimer = 0.65;
        }
        break;
      }
      case 'attack': {
        this.burstCd -= dt;
        if (this.burstLeft > 0 && this.burstCd <= 0) {
          this.burstLeft--;
          this.burstCd = 0.13;
          onShoot([
            new Bullet({
              x: cx + Math.cos(this.aimAngle) * 8,
              y: cy + Math.sin(this.aimAngle) * 8,
              vx: Math.cos(this.aimAngle) * 230,
              vy: Math.sin(this.aimAngle) * 230,
              fromPlayer: false,
              damage: 1,
              knockback: 70,
              color: PALETTE.neonRed,
            }),
          ]);
        }
        this.stateTimer -= dt;
        if (this.stateTimer <= 0) {
          this.state = 'retreat';
          this.stateTimer = 0.9;
        }
        break;
      }
      case 'retreat': {
        // Cooldown cycle
        this.stateTimer -= dt;
        if (this.stateTimer <= 0) {
          this.state = hasSight ? 'alert' : 'patrol';
          this.stateTimer = 0.4;
        }
        break;
      }
    }
  }

  public render(ctx: CanvasRenderingContext2D, camX: number, camY: number): void {
    const sx = Math.round(this.x - camX);
    const sy = Math.round(this.y - camY);
    if (this.state === 'dead') {
      ctx.globalAlpha = Math.max(0, this.deadTimer / 0.32);
    }

    if (this.hitFlashTimer > 0) {
      ctx.fillStyle = PALETTE.white;
      ctx.fillRect(sx, sy, this.w, this.h);
      ctx.globalAlpha = 1;
      return;
    }

    // Ceiling mount base
    ctx.fillStyle = PALETTE.steelMid;
    ctx.fillRect(sx + 1, sy, 14, 5);
    ctx.fillStyle = PALETTE.steelDark;
    ctx.fillRect(sx + 3, sy + 5, 10, 6);

    // Barrel aiming line
    const cx = sx + 8;
    const cy = sy + 9;
    const bx = Math.round(cx + Math.cos(this.aimAngle) * 9);
    const by = Math.round(cy + Math.sin(this.aimAngle) * 9);
    ctx.strokeStyle = PALETTE.steelLight;
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(cx, cy);
    ctx.lineTo(bx, by);
    ctx.stroke();

    // Laser sight telegraph when locked
    if (this.state === 'alert') {
      ctx.strokeStyle = 'rgba(255, 43, 69, 0.55)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(cx, cy);
      ctx.lineTo(cx + Math.cos(this.aimAngle) * 70, cy + Math.sin(this.aimAngle) * 70);
      ctx.stroke();
    }

    // Sensor LED
    ctx.fillStyle = this.state === 'alert' || this.state === 'attack' ? PALETTE.neonRed : PALETTE.neonAmber;
    ctx.fillRect(sx + 6, sy + 6, 4, 3);

    ctx.globalAlpha = 1;
  }
}

export function createEnemy(def: EnemySpawnDef): Enemy {
  switch (def.kind) {
    case 'thug':
      return new GangThug(def);
    case 'heavy':
      return new HeavyShotgunner(def);
    case 'drone':
      return new SecurityDrone(def);
    case 'turret':
      return new WallTurret(def);
  }
}
