import { DOOR_COLORS, PALETTE, TILE_SIZE } from './config';
import type { DoorColor, PickupKind, PropKind, Rect, WeaponId } from './types';
import type { ButtonDef, DoorDef, ElevatorDef } from './levelData';

export class Bullet {
  public active = true;
  public x: number;
  public y: number;
  public prevX: number;
  public prevY: number;
  public vx: number;
  public vy: number;
  public w: number;
  public h: number;
  public fromPlayer: boolean;
  public damage: number;
  public knockback: number;
  public color: string;
  public life: number;

  constructor(opts: {
    x: number;
    y: number;
    vx: number;
    vy: number;
    fromPlayer: boolean;
    damage: number;
    knockback: number;
    color: string;
    size?: number;
    life?: number;
  }) {
    this.x = opts.x;
    this.y = opts.y;
    this.prevX = opts.x;
    this.prevY = opts.y;
    this.vx = opts.vx;
    this.vy = opts.vy;
    const sz = opts.size ?? (opts.fromPlayer ? 5 : 4);
    this.w = sz;
    this.h = opts.fromPlayer ? 3 : 4;
    this.fromPlayer = opts.fromPlayer;
    this.damage = opts.damage;
    this.knockback = opts.knockback;
    this.color = opts.color;
    this.life = opts.life ?? 1.4;
  }

  public getRect(): Rect {
    return { x: this.x - this.w * 0.5, y: this.y - this.h * 0.5, w: this.w, h: this.h };
  }

  public update(dt: number): void {
    this.prevX = this.x;
    this.prevY = this.y;
    this.x += this.vx * dt;
    this.y += this.vy * dt;
    this.life -= dt;
    if (this.life <= 0) this.active = false;
  }

  public render(ctx: CanvasRenderingContext2D, camX: number, camY: number): void {
    const sx = Math.round(this.x - camX);
    const sy = Math.round(this.y - camY);
    const px = Math.round(this.prevX - camX);
    const py = Math.round(this.prevY - camY);

    // Pixel tracer line
    ctx.strokeStyle = this.color;
    ctx.lineWidth = this.fromPlayer ? 2 : 2;
    ctx.beginPath();
    ctx.moveTo(px, py);
    ctx.lineTo(sx, sy);
    ctx.stroke();

    // Hot white core
    ctx.fillStyle = PALETTE.white;
    ctx.fillRect(sx - 1, sy - 1, 3, 2);
  }
}

export class Door {
  public readonly id: string;
  public readonly color: DoorColor;
  public readonly x: number;
  public readonly y: number;
  public readonly w: number;
  public readonly h: number;
  public readonly timedSeconds: number | null;
  public openAmount = 0; // 0 = closed, 1 = fully open
  public isOpen = false;
  public timerRemaining = 0;
  public pulseTime = 0;

  constructor(def: DoorDef) {
    this.id = def.id;
    this.color = def.color;
    this.x = def.col * TILE_SIZE + 3;
    this.y = def.topRow * TILE_SIZE;
    this.w = TILE_SIZE - 6;
    this.h = def.heightTiles * TILE_SIZE;
    this.timedSeconds = def.timedSeconds;
  }

  public open(onPlaySlide?: (opening: boolean) => void): void {
    if (!this.isOpen) {
      this.isOpen = true;
      onPlaySlide?.(true);
    }
    if (this.timedSeconds !== null) {
      this.timerRemaining = this.timedSeconds;
    }
  }

  public isBlocking(): boolean {
    return this.openAmount < 0.72;
  }

  public getSolidRect(): Rect | null {
    if (!this.isBlocking()) return null;
    const closedH = Math.round(this.h * (1 - this.openAmount));
    if (closedH <= 2) return null;
    return { x: this.x, y: this.y, w: this.w, h: closedH };
  }

  public update(
    dt: number,
    playerRect: Rect,
    onPlaySlide?: (opening: boolean) => void,
    onTimerTick?: () => void
  ): void {
    this.pulseTime += dt;

    if (this.isOpen && this.timedSeconds !== null) {
      const prevSec = Math.ceil(this.timerRemaining);
      this.timerRemaining -= dt;
      const nextSec = Math.ceil(this.timerRemaining);
      if (this.timerRemaining > 0 && this.timerRemaining <= 5 && nextSec !== prevSec) {
        onTimerTick?.();
      }
      if (this.timerRemaining <= 0) {
        this.timerRemaining = 0;
        // Don't crush player if standing directly inside the doorway
        const doorway: Rect = { x: this.x - 2, y: this.y, w: this.w + 4, h: this.h };
        const overlapPlayer =
          playerRect.x < doorway.x + doorway.w &&
          playerRect.x + playerRect.w > doorway.x &&
          playerRect.y < doorway.y + doorway.h &&
          playerRect.y + playerRect.h > doorway.y;
        if (!overlapPlayer) {
          this.isOpen = false;
          onPlaySlide?.(false);
        }
      }
    }

    const target = this.isOpen ? 1 : 0;
    const speed = 3.2;
    if (this.openAmount < target) {
      this.openAmount = Math.min(1, this.openAmount + speed * dt);
    } else if (this.openAmount > target) {
      this.openAmount = Math.max(0, this.openAmount - speed * dt);
    }
  }

  public render(ctx: CanvasRenderingContext2D, camX: number, camY: number): void {
    const sx = Math.round(this.x - camX);
    const sy = Math.round(this.y - camY);
    const palette = DOOR_COLORS[this.color];

    // Frame header & rails
    ctx.fillStyle = PALETTE.steelDark;
    ctx.fillRect(sx - 2, sy - 4, this.w + 4, 4);
    ctx.fillStyle = palette.main;
    ctx.fillRect(sx, sy - 3, this.w, 2);

    const closedH = Math.round(this.h * (1 - this.openAmount));
    if (closedH > 0) {
      // Heavy blast door slab
      ctx.fillStyle = '#14182b';
      ctx.fillRect(sx, sy, this.w, closedH);

      // Steel border
      ctx.fillStyle = PALETTE.steelLight;
      ctx.fillRect(sx, sy, 2, closedH);
      ctx.fillRect(sx + this.w - 2, sy, 2, closedH);

      // Glowing color-coded energy strips
      const pulse = 0.65 + 0.35 * Math.sin(this.pulseTime * 5);
      ctx.globalAlpha = pulse;
      ctx.fillStyle = palette.main;
      ctx.fillRect(sx + 3, sy + 3, this.w - 6, Math.max(0, closedH - 6));
      ctx.fillStyle = palette.glow;
      ctx.fillRect(sx + 4, sy + 4, 2, Math.max(0, closedH - 8));
      ctx.globalAlpha = 1;

      // Crossbars
      ctx.fillStyle = '#0c0f1d';
      for (let by = 8; by < closedH - 4; by += 10) {
        ctx.fillRect(sx + 2, sy + by, this.w - 4, 2);
      }
    }

    // Countdown bar above timed door when open
    if (this.isOpen && this.timedSeconds !== null && this.timerRemaining > 0) {
      const ratio = Math.max(0, this.timerRemaining / this.timedSeconds);
      ctx.fillStyle = '#0a0c17';
      ctx.fillRect(sx - 6, sy - 9, this.w + 12, 4);
      ctx.fillStyle = ratio < 0.3 ? PALETTE.neonRed : palette.main;
      ctx.fillRect(sx - 5, sy - 8, Math.round((this.w + 10) * ratio), 2);
    }
  }
}

export class ButtonTerminal {
  public readonly id: string;
  public readonly color: DoorColor;
  public readonly x: number;
  public readonly y: number;
  public readonly w = 16;
  public readonly h = 22;
  public readonly label: string;
  public activated = false;
  public pressAnim = 0;

  constructor(def: ButtonDef) {
    this.id = def.id;
    this.color = def.color;
    this.x = def.col * TILE_SIZE;
    this.y = def.row * TILE_SIZE - this.h;
    this.label = def.label;
  }

  public getInteractRect(): Rect {
    return { x: this.x - 10, y: this.y - 6, w: this.w + 20, h: this.h + 10 };
  }

  public trigger(): void {
    this.activated = true;
    this.pressAnim = 0.35;
  }

  public update(dt: number): void {
    if (this.pressAnim > 0) this.pressAnim = Math.max(0, this.pressAnim - dt);
  }

  public render(ctx: CanvasRenderingContext2D, camX: number, camY: number, time: number): void {
    const sx = Math.round(this.x - camX);
    const sy = Math.round(this.y - camY + (this.pressAnim > 0 ? 1 : 0));
    const palette = DOOR_COLORS[this.color];

    // Pedestal base
    ctx.fillStyle = PALETTE.steelMid;
    ctx.fillRect(sx + 2, sy + 10, 12, 12);
    ctx.fillStyle = PALETTE.steelDark;
    ctx.fillRect(sx + 4, sy + 12, 8, 10);

    // Console head
    ctx.fillStyle = PALETTE.steelLight;
    ctx.fillRect(sx, sy, 16, 11);
    ctx.fillStyle = '#090c17';
    ctx.fillRect(sx + 2, sy + 2, 12, 7);

    // Glowing indicator screen
    const blink = this.activated || Math.sin(time * 6) > 0;
    ctx.fillStyle = this.activated ? palette.glow : blink ? palette.main : palette.dark;
    ctx.fillRect(sx + 3, sy + 3, 10, 5);

    // Status LED
    ctx.fillStyle = this.activated ? PALETTE.neonGreen : palette.main;
    ctx.fillRect(sx + 6, sy + 14, 4, 2);
  }
}

export class Elevator {
  public readonly id: string;
  public readonly x: number;
  public y: number;
  public prevY: number;
  public readonly w: number;
  public readonly h = 10;
  public readonly topY: number;
  public readonly bottomY: number;
  public readonly speed: number;
  public targetY: number;
  public moving = false;
  public riderDwell = 0;
  private awaitingExit = false;

  constructor(def: ElevatorDef) {
    this.id = def.id;
    this.x = def.col * TILE_SIZE;
    this.w = def.widthTiles * TILE_SIZE;
    this.topY = def.topRow * TILE_SIZE;
    this.bottomY = def.bottomRow * TILE_SIZE;
    this.y = this.bottomY;
    this.prevY = this.y;
    this.targetY = this.bottomY;
    this.speed = def.speed;
  }

  public getRect(): Rect {
    return { x: this.x, y: this.y, w: this.w, h: this.h };
  }

  public toggleDirection(onStartMove?: () => void): void {
    const distTop = Math.abs(this.y - this.topY);
    const distBot = Math.abs(this.y - this.bottomY);
    this.targetY = distTop < distBot ? this.bottomY : this.topY;
    if (Math.abs(this.targetY - this.y) > 1) {
      this.moving = true;
      this.riderDwell = 0;
      onStartMove?.();
    }
  }

  public callToFloor(floorY: number, onStartMove?: () => void): void {
    const desired = Math.abs(floorY - this.topY) < Math.abs(floorY - this.bottomY) ? this.topY : this.bottomY;
    if (Math.abs(this.y - desired) > 2) {
      this.targetY = desired;
      this.moving = true;
      onStartMove?.();
    }
  }

  public isPlayerOnTop(playerRect: Rect): boolean {
    const horiz = playerRect.x + playerRect.w > this.x + 2 && playerRect.x < this.x + this.w - 2;
    const feet = playerRect.y + playerRect.h;
    return horiz && Math.abs(feet - this.y) <= 4;
  }

  public isNearCallSwitch(playerRect: Rect): number | null {
    const cx = playerRect.x + playerRect.w * 0.5;
    const cy = playerRect.y + playerRect.h;
    const inShaftX = cx >= this.x - 24 && cx <= this.x + this.w + 24;
    if (!inShaftX) return null;
    if (Math.abs(cy - this.topY) <= 22) return this.topY;
    if (Math.abs(cy - this.bottomY) <= 22) return this.bottomY;
    return null;
  }

  public update(dt: number, playerOnTop: boolean, onStartMove?: () => void): number {
    this.prevY = this.y;

    if (!playerOnTop) {
      this.riderDwell = 0;
      this.awaitingExit = false;
    } else if (!this.moving && !this.awaitingExit) {
      this.riderDwell += dt;
      if (this.riderDwell >= 0.42) {
        this.toggleDirection(onStartMove);
      }
    }

    if (this.moving) {
      const diff = this.targetY - this.y;
      const step = this.speed * dt;
      if (Math.abs(diff) <= step) {
        this.y = this.targetY;
        this.moving = false;
        this.awaitingExit = playerOnTop;
      } else {
        this.y += Math.sign(diff) * step;
      }
    }

    return this.y - this.prevY;
  }

  public render(ctx: CanvasRenderingContext2D, camX: number, camY: number, time: number): void {
    const sx = Math.round(this.x - camX);
    const sy = Math.round(this.y - camY);
    const topScreenY = Math.round(this.topY - camY);
    const botScreenY = Math.round(this.bottomY - camY);

    // Shaft vertical guide rails
    ctx.fillStyle = '#181e36';
    ctx.fillRect(sx + 2, topScreenY - 12, 2, botScreenY - topScreenY + 22);
    ctx.fillRect(sx + this.w - 4, topScreenY - 12, 2, botScreenY - topScreenY + 22);

    // Call beacon lights at top and bottom stops
    const beacon = Math.sin(time * 4) > 0 ? PALETTE.neonCyan : '#0b4e5e';
    ctx.fillStyle = beacon;
    ctx.fillRect(sx - 4, topScreenY - 14, 3, 5);
    ctx.fillRect(sx + this.w + 1, botScreenY - 14, 3, 5);

    // Elevator platform deck
    ctx.fillStyle = PALETTE.steelLight;
    ctx.fillRect(sx, sy, this.w, 3);
    ctx.fillStyle = PALETTE.neonCyan;
    ctx.fillRect(sx + 2, sy, this.w - 4, 1);
    ctx.fillStyle = PALETTE.steelDark;
    ctx.fillRect(sx + 1, sy + 3, this.w - 2, this.h - 3);

    // Caution stripes on side trim
    ctx.fillStyle = PALETTE.neonAmber;
    for (let px = 4; px < this.w - 6; px += 10) {
      ctx.fillRect(sx + px, sy + 5, 5, 3);
    }

    // Moving direction indicator
    if (this.moving) {
      ctx.fillStyle = PALETTE.neonGreen;
      const dirArrowY = this.targetY < this.y ? sy + 2 : sy + 6;
      ctx.fillRect(sx + (this.w >> 1) - 2, dirArrowY, 4, 2);
    }
  }
}

export class Prop {
  public active = true;
  public readonly kind: PropKind;
  public readonly x: number;
  public readonly y: number;
  public readonly w: number;
  public readonly h: number;
  public hp: number;
  public flashTimer = 0;
  public readonly drop?: PickupKind;

  constructor(kind: PropKind, col: number, row: number, drop?: PickupKind) {
    this.kind = kind;
    this.w = kind === 'monitor' ? 16 : 14;
    this.h = kind === 'barrel' ? 18 : 16;
    this.x = col * TILE_SIZE + 1;
    this.y = row * TILE_SIZE - this.h;
    this.hp = kind === 'barrel' ? 2 : 3;
    this.drop = drop;
  }

  public getRect(): Rect {
    return { x: this.x, y: this.y, w: this.w, h: this.h };
  }

  public render(ctx: CanvasRenderingContext2D, camX: number, camY: number, time: number): void {
    if (!this.active) return;
    const sx = Math.round(this.x - camX);
    const sy = Math.round(this.y - camY);

    if (this.flashTimer > 0) {
      ctx.fillStyle = PALETTE.white;
      ctx.fillRect(sx, sy, this.w, this.h);
      return;
    }

    if (this.kind === 'crate') {
      ctx.fillStyle = '#4e3524';
      ctx.fillRect(sx, sy, this.w, this.h);
      ctx.fillStyle = '#7c5234';
      ctx.fillRect(sx + 1, sy + 1, this.w - 2, 2);
      ctx.fillRect(sx + 1, sy + this.h - 3, this.w - 2, 2);
      ctx.fillStyle = '#2d1c12';
      ctx.fillRect(sx + 3, sy + 4, this.w - 6, this.h - 8);
      ctx.fillStyle = PALETTE.neonAmber;
      ctx.fillRect(sx + 5, sy + 7, 4, 2);
    } else if (this.kind === 'monitor') {
      ctx.fillStyle = PALETTE.steelMid;
      ctx.fillRect(sx, sy, this.w, this.h);
      ctx.fillStyle = '#071422';
      ctx.fillRect(sx + 2, sy + 2, this.w - 4, 9);
      ctx.fillStyle = Math.sin(time * 9 + this.x) > 0 ? PALETTE.neonCyan : PALETTE.neonPink;
      ctx.fillRect(sx + 3, sy + 4, 7, 2);
      ctx.fillRect(sx + 3, sy + 7, 10, 1);
      ctx.fillStyle = PALETTE.steelDark;
      ctx.fillRect(sx + 4, sy + 12, 8, 4);
    } else {
      // Explosive Barrel
      ctx.fillStyle = '#991b2b';
      ctx.fillRect(sx + 1, sy, this.w - 2, this.h);
      ctx.fillStyle = '#d92638';
      ctx.fillRect(sx + 3, sy + 2, this.w - 6, this.h - 4);
      ctx.fillStyle = PALETTE.neonYellow;
      ctx.fillRect(sx + 1, sy + 6, this.w - 2, 4);
      ctx.fillStyle = '#111118';
      ctx.fillRect(sx + 5, sy + 7, 4, 2);
    }
  }
}

export class Pickup {
  public active = true;
  public readonly kind: PickupKind;
  public readonly x: number;
  public readonly y: number;
  public readonly w = 14;
  public readonly h = 12;

  constructor(kind: PickupKind, x: number, y: number) {
    this.kind = kind;
    this.x = x;
    this.y = y;
  }

  public getRect(): Rect {
    return { x: this.x, y: this.y, w: this.w, h: this.h };
  }

  public getWeaponId(): WeaponId | null {
    if (this.kind === 'shotgun') return 'shotgun';
    if (this.kind === 'smg') return 'smg';
    return null;
  }

  public render(ctx: CanvasRenderingContext2D, camX: number, camY: number, time: number): void {
    if (!this.active) return;
    const bob = Math.round(Math.sin(time * 5 + this.x * 0.1) * 2);
    const sx = Math.round(this.x - camX);
    const sy = Math.round(this.y - camY + bob);

    if (this.kind === 'health') {
      ctx.fillStyle = '#f8fafc';
      ctx.fillRect(sx + 1, sy + 1, 12, 10);
      ctx.fillStyle = PALETTE.neonGreen;
      ctx.fillRect(sx + 5, sy + 2, 4, 8);
      ctx.fillRect(sx + 3, sy + 4, 8, 4);
    } else if (this.kind === 'shotgun') {
      ctx.fillStyle = '#181c30';
      ctx.fillRect(sx, sy + 2, 14, 8);
      ctx.fillStyle = PALETTE.neonAmber;
      ctx.fillRect(sx + 1, sy + 4, 12, 3);
      ctx.fillStyle = '#7c4a24';
      ctx.fillRect(sx + 1, sy + 6, 4, 3);
    } else if (this.kind === 'smg') {
      ctx.fillStyle = '#181c30';
      ctx.fillRect(sx, sy + 2, 14, 8);
      ctx.fillStyle = PALETTE.neonCyan;
      ctx.fillRect(sx + 2, sy + 3, 10, 3);
      ctx.fillRect(sx + 6, sy + 6, 2, 4);
    } else {
      // Ammo crate
      ctx.fillStyle = '#243018';
      ctx.fillRect(sx + 1, sy + 2, 12, 9);
      ctx.fillStyle = PALETTE.neonYellow;
      ctx.fillRect(sx + 3, sy + 4, 2, 5);
      ctx.fillRect(sx + 6, sy + 4, 2, 5);
      ctx.fillRect(sx + 9, sy + 4, 2, 5);
    }
  }
}
