import { PALETTE, TILE_SIZE } from './config';
import type { Rect } from './types';

export type TileKind = 'empty' | 'solid' | 'oneway';

export interface TileCollisionResult {
  hitLeft: boolean;
  hitRight: boolean;
  hitTop: boolean;
  hitBottom: boolean;
  onOneWay: boolean;
}

export class Tilemap {
  public readonly cols: number;
  public readonly rows: number;
  public readonly worldWidth: number;
  public readonly worldHeight: number;
  private readonly grid: TileKind[][];

  constructor(asciiRows: string[]) {
    this.rows = asciiRows.length;
    this.cols = asciiRows[0]?.length ?? 0;
    this.worldWidth = this.cols * TILE_SIZE;
    this.worldHeight = this.rows * TILE_SIZE;
    this.grid = asciiRows.map((row) =>
      row.split('').map((ch) => {
        if (ch === '#') return 'solid';
        if (ch === '=') return 'oneway';
        return 'empty';
      })
    );
  }

  public getTile(col: number, row: number): TileKind {
    if (col < 0 || col >= this.cols || row < 0 || row >= this.rows) {
      return 'solid';
    }
    return this.grid[row][col];
  }

  public isSolidAtPixel(wx: number, wy: number): boolean {
    const col = Math.floor(wx / TILE_SIZE);
    const row = Math.floor(wy / TILE_SIZE);
    return this.getTile(col, row) === 'solid';
  }

  public hasLineOfSight(
    x0: number,
    y0: number,
    x1: number,
    y1: number,
    blockingRects: Rect[] = []
  ): boolean {
    const dx = x1 - x0;
    const dy = y1 - y0;
    const dist = Math.hypot(dx, dy);
    const steps = Math.max(1, Math.ceil(dist / 6));
    for (let i = 1; i < steps; i++) {
      const t = i / steps;
      const px = x0 + dx * t;
      const py = y0 + dy * t;
      if (this.isSolidAtPixel(px, py)) return false;
      for (let j = 0; j < blockingRects.length; j++) {
        const r = blockingRects[j];
        if (px >= r.x && px <= r.x + r.w && py >= r.y && py <= r.y + r.h) {
          return false;
        }
      }
    }
    return true;
  }

  /**
   * Resolves AABB movement against solid tiles, one-way platforms, and dynamic
   * solid barriers (such as closed security doors).
   */
  public moveAndCollide(
    rect: Rect,
    vx: number,
    vy: number,
    dt: number,
    options: {
      dropThroughOneWay?: boolean;
      extraSolids?: Rect[];
    } = {}
  ): TileCollisionResult {
    const res: TileCollisionResult = {
      hitLeft: false,
      hitRight: false,
      hitTop: false,
      hitBottom: false,
      onOneWay: false,
    };
    const extraSolids = options.extraSolids ?? [];

    // 1. Move horizontally and resolve X collisions
    rect.x += vx * dt;
    const minRowX = Math.floor((rect.y + 0.5) / TILE_SIZE);
    const maxRowX = Math.floor((rect.y + rect.h - 0.5) / TILE_SIZE);
    const minColX = Math.floor(rect.x / TILE_SIZE);
    const maxColX = Math.floor((rect.x + rect.w - 0.01) / TILE_SIZE);

    for (let r = minRowX; r <= maxRowX; r++) {
      for (let c = minColX; c <= maxColX; c++) {
        if (this.getTile(c, r) === 'solid') {
          const tileX = c * TILE_SIZE;
          if (vx > 0) {
            rect.x = tileX - rect.w;
            res.hitRight = true;
          } else if (vx < 0) {
            rect.x = tileX + TILE_SIZE;
            res.hitLeft = true;
          }
        }
      }
    }

    for (let i = 0; i < extraSolids.length; i++) {
      const s = extraSolids[i];
      if (aabbOverlap(rect, s)) {
        if (vx > 0) {
          rect.x = s.x - rect.w;
          res.hitRight = true;
        } else if (vx < 0) {
          rect.x = s.x + s.w;
          res.hitLeft = true;
        }
      }
    }

    // 2. Move vertically and resolve Y collisions
    const prevBottom = rect.y + rect.h;
    rect.y += vy * dt;

    const minColY = Math.floor((rect.x + 0.5) / TILE_SIZE);
    const maxColY = Math.floor((rect.x + rect.w - 0.5) / TILE_SIZE);
    const minRowY = Math.floor(rect.y / TILE_SIZE);
    const maxRowY = Math.floor((rect.y + rect.h - 0.01) / TILE_SIZE);

    for (let r = minRowY; r <= maxRowY; r++) {
      for (let c = minColY; c <= maxColY; c++) {
        const tile = this.getTile(c, r);
        const tileY = r * TILE_SIZE;
        if (tile === 'solid') {
          if (vy > 0) {
            rect.y = tileY - rect.h;
            res.hitBottom = true;
          } else if (vy < 0) {
            rect.y = tileY + TILE_SIZE;
            res.hitTop = true;
          }
        } else if (tile === 'oneway' && vy >= 0 && !options.dropThroughOneWay) {
          if (prevBottom <= tileY + 3 && rect.y + rect.h >= tileY) {
            rect.y = tileY - rect.h;
            res.hitBottom = true;
            res.onOneWay = true;
          }
        }
      }
    }

    for (let i = 0; i < extraSolids.length; i++) {
      const s = extraSolids[i];
      if (aabbOverlap(rect, s)) {
        if (vy > 0) {
          rect.y = s.y - rect.h;
          res.hitBottom = true;
        } else if (vy < 0) {
          rect.y = s.y + s.h;
          res.hitTop = true;
        }
      }
    }

    return res;
  }

  public renderVisibleTiles(
    ctx: CanvasRenderingContext2D,
    camX: number,
    camY: number,
    viewW: number,
    viewH: number
  ): void {
    const startCol = Math.max(0, Math.floor(camX / TILE_SIZE));
    const endCol = Math.min(this.cols - 1, Math.floor((camX + viewW) / TILE_SIZE) + 1);
    const startRow = Math.max(0, Math.floor(camY / TILE_SIZE));
    const endRow = Math.min(this.rows - 1, Math.floor((camY + viewH) / TILE_SIZE) + 1);

    for (let r = startRow; r <= endRow; r++) {
      for (let c = startCol; c <= endCol; c++) {
        const tile = this.grid[r][c];
        if (tile === 'empty') continue;

        const sx = Math.round(c * TILE_SIZE - camX);
        const sy = Math.round(r * TILE_SIZE - camY);

        if (tile === 'solid') {
          const aboveEmpty = this.getTile(c, r - 1) !== 'solid';
          const belowEmpty = this.getTile(c, r + 1) !== 'solid';
          const leftEmpty = this.getTile(c - 1, r) !== 'solid';
          const rightEmpty = this.getTile(c + 1, r) !== 'solid';

          // Core metal slab with beveled recessed plate
          ctx.fillStyle = '#1b2038';
          ctx.fillRect(sx, sy, TILE_SIZE, TILE_SIZE);
          ctx.fillStyle = '#111526';
          ctx.fillRect(sx + 2, sy + 2, TILE_SIZE - 4, TILE_SIZE - 4);
          ctx.fillStyle = '#171c33';
          ctx.fillRect(sx + 3, sy + 3, TILE_SIZE - 6, TILE_SIZE - 6);

          // Corner rivets + micro seam
          ctx.fillStyle = '#333d63';
          ctx.fillRect(sx + 3, sy + 3, 2, 2);
          ctx.fillRect(sx + TILE_SIZE - 5, sy + 3, 2, 2);
          ctx.fillRect(sx + 3, sy + TILE_SIZE - 5, 2, 2);
          ctx.fillRect(sx + TILE_SIZE - 5, sy + TILE_SIZE - 5, 2, 2);
          if ((c + r) % 3 === 0) {
            ctx.fillStyle = '#252d4a';
            ctx.fillRect(sx + 5, sy + 7, 6, 2);
          }

          if (aboveEmpty) {
            // Top floor deck plate + metallic edge + hazard stripe accents
            ctx.fillStyle = PALETTE.steelMid;
            ctx.fillRect(sx, sy, TILE_SIZE, 3);
            ctx.fillStyle = PALETTE.steelEdge;
            ctx.fillRect(sx, sy, TILE_SIZE, 1);
            if ((c + r) % 4 === 0) {
              ctx.fillStyle = '#d98200';
              ctx.fillRect(sx + 1, sy + 1, 5, 2);
              ctx.fillRect(sx + 9, sy + 1, 5, 2);
            } else if (c % 7 === 0) {
              ctx.fillStyle = '#00a8b8';
              ctx.fillRect(sx + 5, sy + 1, 6, 1);
            }
          }
          if (belowEmpty) {
            // Underside ceiling trim with subtle pipe shadow
            ctx.fillStyle = '#090b15';
            ctx.fillRect(sx, sy + TILE_SIZE - 2, TILE_SIZE, 2);
            ctx.fillStyle = '#283052';
            ctx.fillRect(sx + 2, sy + TILE_SIZE - 3, TILE_SIZE - 4, 1);
          }
          if (leftEmpty) {
            ctx.fillStyle = PALETTE.steelLight;
            ctx.fillRect(sx, sy, 2, TILE_SIZE);
          }
          if (rightEmpty) {
            ctx.fillStyle = '#0d101f';
            ctx.fillRect(sx + TILE_SIZE - 2, sy, 2, TILE_SIZE);
          }
        } else if (tile === 'oneway') {
          // Detailed grated cyber-catwalk with cyan edge & lower steel girder
          ctx.fillStyle = PALETTE.steelLight;
          ctx.fillRect(sx, sy, TILE_SIZE, 3);
          ctx.fillStyle = PALETTE.neonCyan;
          ctx.fillRect(sx, sy, TILE_SIZE, 1);
          ctx.fillStyle = '#0c1021';
          ctx.fillRect(sx, sy + 3, TILE_SIZE, 4);
          ctx.fillStyle = PALETTE.steelMid;
          ctx.fillRect(sx, sy + 6, TILE_SIZE, 1);
          for (let px = 1; px < TILE_SIZE; px += 4) {
            ctx.fillRect(sx + px, sy + 3, 1, 3);
            ctx.fillStyle = '#3c4770';
            ctx.fillRect(sx + px + 1, sy + 4, 1, 1);
            ctx.fillStyle = PALETTE.steelMid;
          }
        }
      }
    }
  }
}

export function aabbOverlap(a: Rect, b: Rect): boolean {
  return a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;
}
