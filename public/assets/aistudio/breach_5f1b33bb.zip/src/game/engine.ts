import { AudioEngine } from './audio';
import { BackgroundRenderer } from './background';
import {
  DOOR_COLORS,
  FIXED_DT,
  INTERNAL_HEIGHT,
  INTERNAL_WIDTH,
  MAX_FRAME_DT,
  PALETTE,
  TILE_SIZE,
  WEAPONS,
} from './config';
import { createEnemy, Enemy } from './enemies';
import { Bullet, ButtonTerminal, Door, Elevator, Pickup, Prop } from './entities';
import {
  BUTTON_DEFS,
  DOOR_DEFS,
  ELEVATOR_DEFS,
  ENEMY_SPAWNS,
  LEVEL_ASCII,
  LEVEL_CHECKPOINT,
  LEVEL_EXIT,
  LEVEL_SPAWN,
  PICKUP_SPAWNS,
  PROP_SPAWNS,
  STEAM_VENTS,
} from './levelData';
import { ParticlePool } from './particles';
import { Player } from './player';
import { aabbOverlap, Tilemap } from './tilemap';
import type { GamePhase, HudSnapshot, InputSnapshot, Rect, WeaponId } from './types';

export interface FloatingToast {
  x: number;
  y: number;
  text: string;
  color: string;
  life: number;
}

export class GameEngine {
  public readonly tilemap: Tilemap;
  public readonly particles: ParticlePool;
  public readonly audio: AudioEngine;
  public readonly background: BackgroundRenderer;

  public phase: GamePhase = 'title';
  public player!: Player;
  public enemies: Enemy[] = [];
  public bullets: Bullet[] = [];
  public elevators: Elevator[] = [];
  public doors: Door[] = [];
  public buttons: ButtonTerminal[] = [];
  public props: Prop[] = [];
  public pickups: Pickup[] = [];
  public toasts: FloatingToast[] = [];

  public camX = 0;
  public camY = 0;
  public trauma = 0;
  public hitstopTimer = 0;

  public simTime = 0;
  public runElapsed = 0;
  public kills = 0;
  public totalEnemies = 0;
  public propsDestroyed = 0;
  public damageTaken = 0;
  public checkpointSaved = false;
  public crtEnabled = true;

  public bannerText: string | null = null;
  private bannerTimer = 0;
  public promptText: string | null = null;
  private activePromptPos: { x: number; y: number } | null = null;

  private canvas: HTMLCanvasElement | null = null;
  private ctx: CanvasRenderingContext2D | null = null;
  private rafId: number | null = null;
  private lastTimestamp = 0;
  private accumulator = 0;
  private steamTimer = 0;
  private hudEmitTimer = 0;

  // Input state
  private heldKeys = new Set<string>();
  private justPressedKeys = new Set<string>();
  private prevGamepadButtons: boolean[] = [];

  private onHudChange?: (snapshot: HudSnapshot) => void;

  constructor(onHudChange?: (snapshot: HudSnapshot) => void) {
    this.onHudChange = onHudChange;
    this.tilemap = new Tilemap(LEVEL_ASCII);
    this.particles = new ParticlePool(420);
    this.audio = new AudioEngine();
    this.background = new BackgroundRenderer();
    this.resetWorld(false);
  }

  public mount(canvas: HTMLCanvasElement): () => void {
    this.canvas = canvas;
    this.canvas.width = INTERNAL_WIDTH;
    this.canvas.height = INTERNAL_HEIGHT;
    this.ctx = canvas.getContext('2d', { alpha: false });

    const onUnlock = () => {
      this.audio.unlockFromGesture();
    };

    const onKeyDown = (e: KeyboardEvent) => {
      this.audio.unlockFromGesture();
      if (
        ['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Space', 'ControlLeft', 'ControlRight'].includes(e.code) ||
        (this.phase === 'playing' && (e.ctrlKey || e.metaKey))
      ) {
        e.preventDefault();
      }
      if (!e.repeat) {
        this.justPressedKeys.add(e.code);
      }
      this.heldKeys.add(e.code);

      if (!e.repeat) {
        if (e.code === 'KeyM') {
          this.toggleMute();
        } else if (e.code === 'KeyC') {
          this.toggleCrt();
        } else if (e.code === 'KeyP' || e.code === 'Escape') {
          if (this.phase === 'playing') {
            this.setPhase('paused');
          } else if (this.phase === 'paused') {
            this.setPhase('playing');
          }
        } else if (e.code === 'KeyR' && (this.phase === 'playing' || this.phase === 'defeat')) {
          if (this.checkpointSaved && this.phase === 'defeat') {
            this.respawnAtCheckpoint();
          } else {
            this.startNewRun();
          }
        }
      }
    };

    const onKeyUp = (e: KeyboardEvent) => {
      this.heldKeys.delete(e.code);
    };

    const clearInputs = () => {
      this.heldKeys.clear();
      this.justPressedKeys.clear();
    };

    window.addEventListener('pointerdown', onUnlock);
    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    window.addEventListener('blur', clearInputs);
    document.addEventListener('visibilitychange', clearInputs);

    this.lastTimestamp = performance.now();
    const loop = (now: number) => {
      const rawDt = Math.max(0, (now - this.lastTimestamp) / 1000);
      this.lastTimestamp = now;
      const frameDt = Math.min(rawDt, MAX_FRAME_DT);

      this.tickFrame(frameDt);
      this.render();

      this.rafId = requestAnimationFrame(loop);
    };
    this.rafId = requestAnimationFrame(loop);

    return () => {
      if (this.rafId !== null) cancelAnimationFrame(this.rafId);
      window.removeEventListener('pointerdown', onUnlock);
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      window.removeEventListener('blur', clearInputs);
      document.removeEventListener('visibilitychange', clearInputs);
      this.audio.stopMusic();
    };
  }

  public resetWorld(keepCheckpoint: boolean): void {
    const savedCheckpoint = keepCheckpoint && this.checkpointSaved;
    const savedElapsed = keepCheckpoint ? this.runElapsed : 0;
    const savedKills = keepCheckpoint ? this.kills : 0;
    const savedProps = keepCheckpoint ? this.propsDestroyed : 0;
    const savedDamage = keepCheckpoint ? this.damageTaken : 0;

    if (!keepCheckpoint) {
      this.elevators = ELEVATOR_DEFS.map((d) => new Elevator(d));
      this.doors = DOOR_DEFS.map((d) => new Door(d));
      this.buttons = BUTTON_DEFS.map((d) => new ButtonTerminal(d));
      this.enemies = ENEMY_SPAWNS.map((s) => createEnemy(s));
      this.props = PROP_SPAWNS.map((p) => new Prop(p.kind, p.col, p.row, p.drop));
      this.pickups = PICKUP_SPAWNS.map(
        (p) => new Pickup(p.kind, p.col * TILE_SIZE + 1, p.row * TILE_SIZE - 13)
      );
      this.totalEnemies = this.enemies.length;
    }

    const spawnX = savedCheckpoint
      ? LEVEL_CHECKPOINT.col * TILE_SIZE
      : LEVEL_SPAWN.col * TILE_SIZE;
    const spawnY = savedCheckpoint
      ? LEVEL_CHECKPOINT.row * TILE_SIZE
      : LEVEL_SPAWN.row * TILE_SIZE;

    const prevWeapons = keepCheckpoint ? [...this.player.unlockedWeapons] : (['pistol'] as WeaponId[]);
    const prevAmmo = keepCheckpoint ? { ...this.player.ammo } : { pistol: Infinity, shotgun: 0, smg: 0 };

    this.player = new Player(spawnX, spawnY);
    if (keepCheckpoint) {
      this.player.unlockedWeapons = prevWeapons;
      this.player.ammo = prevAmmo;
      if (prevWeapons.includes('smg') && prevAmmo.smg > 0) this.player.weapon = 'smg';
      else if (prevWeapons.includes('shotgun') && prevAmmo.shotgun > 0) this.player.weapon = 'shotgun';
    }

    this.bullets = [];
    this.particles.clear();
    this.toasts = [];
    this.trauma = 0;
    this.hitstopTimer = 0;

    this.checkpointSaved = savedCheckpoint;
    this.runElapsed = savedElapsed;
    this.kills = savedKills;
    this.propsDestroyed = savedProps;
    this.damageTaken = savedDamage;

    // Snap camera to player
    this.camX = this.clampCamX(this.player.x + this.player.w * 0.5 - INTERNAL_WIDTH * 0.42);
    this.camY = this.clampCamY(this.player.y + this.player.h * 0.5 - INTERNAL_HEIGHT * 0.55);
    this.emitHud();
  }

  public startNewRun(): void {
    this.heldKeys.clear();
    this.justPressedKeys.clear();
    this.checkpointSaved = false;
    this.resetWorld(false);
    this.setPhase('playing');
    this.audio.startMusic();
    this.showBanner('INTERCELL SYNTETICS — REACH EXTRACTION');
  }

  public respawnAtCheckpoint(): void {
    this.heldKeys.clear();
    this.justPressedKeys.clear();
    this.resetWorld(true);
    this.setPhase('playing');
    this.showBanner('RESPAWNED AT CHECKPOINT');
  }

  public setPhase(next: GamePhase): void {
    this.phase = next;
    if (typeof document !== 'undefined') {
      document.body.dataset.state =
        next === 'victory' || next === 'defeat' ? 'gameover' : next;
    }
    if (next === 'paused' || next === 'title') {
      this.audio.stopMusic();
    } else if (next === 'playing') {
      this.audio.startMusic();
    }
    this.emitHud();
  }

  public toggleMute(): boolean {
    const m = this.audio.toggleMute();
    this.emitHud();
    return m;
  }

  public toggleCrt(): boolean {
    this.crtEnabled = !this.crtEnabled;
    this.emitHud();
    return this.crtEnabled;
  }

  public showBanner(text: string, duration = 2.6): void {
    this.bannerText = text;
    this.bannerTimer = duration;
    this.emitHud();
  }

  private pollInput(): InputSnapshot {
    let gpLeft = false;
    let gpRight = false;
    let gpUp = false;
    let gpDown = false;
    let gpJumpHeld = false;
    let gpJumpPressed = false;
    let gpShootHeld = false;
    let gpShootPressed = false;
    let gpDashPressed = false;
    let gpInteractPressed = false;

    if (typeof navigator !== 'undefined' && navigator.getGamepads) {
      const pads = navigator.getGamepads();
      const pad = pads?.[0];
      if (pad) {
        const axX = pad.axes[0] ?? 0;
        const axY = pad.axes[1] ?? 0;
        gpLeft = axX < -0.35 || !!pad.buttons[14]?.pressed;
        gpRight = axX > 0.35 || !!pad.buttons[15]?.pressed;
        gpUp = axY < -0.5 || !!pad.buttons[12]?.pressed;
        gpDown = axY > 0.5 || !!pad.buttons[13]?.pressed;

        const btnStates = pad.buttons.map((b) => !!b.pressed);
        const justBtn = (idx: number) => !!btnStates[idx] && !this.prevGamepadButtons[idx];

        gpJumpHeld = !!btnStates[0];
        gpJumpPressed = justBtn(0);
        gpShootHeld = !!btnStates[2];
        gpShootPressed = justBtn(2);
        gpDashPressed = justBtn(1);
        gpInteractPressed = justBtn(3);
        if (justBtn(9)) {
          if (this.phase === 'playing') this.setPhase('paused');
          else if (this.phase === 'paused') this.setPhase('playing');
        }
        this.prevGamepadButtons = btnStates;
      }
    }

    const k = (code: string) => this.heldKeys.has(code);
    const jp = (code: string) => this.justPressedKeys.has(code);

    const selectWeapon: WeaponId | null = jp('Digit1')
      ? 'pistol'
      : jp('Digit2')
        ? 'shotgun'
        : jp('Digit3')
          ? 'smg'
          : null;

    const snap: InputSnapshot = {
      left: k('KeyA') || k('ArrowLeft') || gpLeft,
      right: k('KeyD') || k('ArrowRight') || gpRight,
      up: k('KeyW') || k('ArrowUp') || gpUp,
      down: k('KeyS') || k('ArrowDown') || gpDown,
      jumpHeld: k('Space') || gpJumpHeld,
      jumpPressed: jp('Space') || gpJumpPressed,
      shootHeld: k('ControlLeft') || k('ControlRight') || k('KeyJ') || k('KeyX') || gpShootHeld,
      shootPressed: jp('ControlLeft') || jp('ControlRight') || jp('KeyJ') || jp('KeyX') || gpShootPressed,
      dashPressed: jp('ShiftLeft') || jp('ShiftRight') || jp('KeyK') || jp('KeyZ') || gpDashPressed,
      interactPressed: jp('KeyE') || gpInteractPressed,
      cycleWeaponPressed: jp('KeyQ'),
      selectWeapon,
    };

    this.justPressedKeys.clear();
    return snap;
  }

  private tickFrame(frameDt: number): void {
    this.simTime += frameDt;
    if (this.trauma > 0) this.trauma = Math.max(0, this.trauma - 1.8 * frameDt);
    if (this.bannerTimer > 0) {
      this.bannerTimer -= frameDt;
      if (this.bannerTimer <= 0) {
        this.bannerText = null;
        this.emitHud();
      }
    }

    if (this.phase === 'title') {
      // Live World Camera Tour across the cyberpunk bunker
      const panSpeed = 38;
      const maxX = Math.max(1, this.tilemap.worldWidth - INTERNAL_WIDTH);
      const t = this.simTime * panSpeed;
      const cycle = Math.floor(t / maxX);
      const pos = t % maxX;
      this.camX = cycle % 2 === 0 ? pos : maxX - pos;
      this.camY = 230 + Math.sin(this.simTime * 0.3) * 140;
      this.camY = this.clampCamY(this.camY);
      this.updateAmbientSteam(frameDt);
      this.particles.update(frameDt, (wx, wy) => this.tilemap.isSolidAtPixel(wx, wy));
      this.justPressedKeys.clear();
      return;
    }

    if (this.phase !== 'playing') {
      this.justPressedKeys.clear();
      return;
    }

    // Hitstop freezes simulation physics briefly while keeping render & screen shake alive
    if (this.hitstopTimer > 0) {
      this.hitstopTimer = Math.max(0, this.hitstopTimer - frameDt);
      return;
    }

    this.accumulator += frameDt;
    while (this.accumulator >= FIXED_DT) {
      this.stepSimulation(FIXED_DT);
      this.accumulator -= FIXED_DT;
    }

    this.hudEmitTimer += frameDt;
    if (this.hudEmitTimer >= 0.1) {
      this.hudEmitTimer = 0;
      this.emitHud();
    }
  }

  public stepSimulation(dt: number): void {
    this.runElapsed += dt;
    const input = this.pollInput();

    // Update doors first so blocking rects reflect current frame
    const pRectPre = this.player.getRect();
    for (let i = 0; i < this.doors.length; i++) {
      this.doors[i].update(
        dt,
        pRectPre,
        (opening) => this.audio.playDoorSlide(opening),
        () => this.audio.playTimerBeep()
      );
    }
    for (let i = 0; i < this.buttons.length; i++) {
      this.buttons[i].update(dt);
    }

    // Update elevators and carry riders safely
    for (let i = 0; i < this.elevators.length; i++) {
      const el = this.elevators[i];
      const playerOnTop = el.isPlayerOnTop(this.player.getRect());
      const dy = el.update(dt, playerOnTop, () => this.audio.playElevatorHum());
      if (dy !== 0) {
        if (playerOnTop && this.player.vy >= -20) {
          this.player.y += dy;
        }
        // Carry any enemies standing on top of the elevator
        for (let j = 0; j < this.enemies.length; j++) {
          const en = this.enemies[j];
          if (!en.isAlive() || en.kind === 'drone' || en.kind === 'turret') continue;
          if (el.isPlayerOnTop(en.getRect())) {
            en.y += dy;
          }
        }
      }
    }

    // Assemble dynamic solid obstacles: closed doors + elevator platforms (solid from above)
    const doorSolids: Rect[] = [];
    for (let i = 0; i < this.doors.length; i++) {
      const s = this.doors[i].getSolidRect();
      if (s) doorSolids.push(s);
    }

    const elevatorSolids: Rect[] = [];
    for (let i = 0; i < this.elevators.length; i++) {
      const el = this.elevators[i];
      // Elevator acts as solid platform if player's feet are at or above its top
      if (this.player.y + this.player.h <= el.prevY + 6) {
        elevatorSolids.push(el.getRect());
      }
    }

    // Update player
    const newBullets = this.player.update(
      dt,
      input,
      this.tilemap,
      [...doorSolids, ...elevatorSolids],
      {
        onJump: () => {
          this.audio.playJump();
          this.particles.burst(
            this.player.x + this.player.w * 0.5,
            this.player.y + this.player.h,
            5,
            ['#64748b', '#00f0ff'],
            25,
            65,
            220,
            'pixel'
          );
        },
        onLand: () => {
          this.particles.burst(
            this.player.x + this.player.w * 0.5,
            this.player.y + this.player.h,
            4,
            ['#475569', '#94a3b8'],
            20,
            55,
            180,
            'pixel'
          );
        },
        onDash: () => {
          this.audio.playDash();
          this.particles.burst(
            this.player.x + this.player.w * 0.5,
            this.player.y + this.player.h * 0.5,
            8,
            [PALETTE.neonCyan, PALETTE.white],
            40,
            110,
            0,
            'spark'
          );
        },
        onShoot: (weaponId, _bullets, mx, my, facing, aimMode) => {
          this.audio.playShoot(weaponId);
          this.particles.spawnCasing(
            this.player.x + this.player.w * 0.5,
            this.player.y + 10,
            facing
          );
          this.particles.spawn({
            x: mx,
            y: my,
            vx: 0,
            vy: 0,
            life: 0.08,
            size: weaponId === 'shotgun' ? 14 : 9,
            color: WEAPONS[weaponId].muzzleColor,
            style: 'glow',
          });
          if (weaponId === 'shotgun') {
            this.addTrauma(0.24);
          } else if (aimMode !== 'straight') {
            this.addTrauma(0.06);
          }
        },
      }
    );

    for (let i = 0; i < newBullets.length; i++) {
      this.bullets.push(newBullets[i]);
    }

    // Dash-roll melee strike check
    const meleeRect = this.player.getMeleeRect();
    if (meleeRect) {
      for (let i = 0; i < this.enemies.length; i++) {
        const en = this.enemies[i];
        if (!en.isAlive() || this.player.meleeHitIds.has(en)) continue;
        if (aabbOverlap(meleeRect, en.getRect())) {
          this.player.meleeHitIds.add(en);
          const killed = en.takeDamage(2, this.player.facing * 150);
          this.audio.playHit(true);
          this.hitstopTimer = 0.04;
          this.addTrauma(0.22);
          this.particles.burst(
            en.x + en.w * 0.5,
            en.y + en.h * 0.5,
            10,
            [PALETTE.neonCyan, PALETTE.white, PALETTE.neonPink],
            50,
            140,
            300,
            'spark'
          );
          if (killed) this.handleEnemyKilled(en);
        }
      }
      for (let i = 0; i < this.props.length; i++) {
        const pr = this.props[i];
        if (!pr.active || this.player.meleeHitIds.has(pr)) continue;
        if (aabbOverlap(meleeRect, pr.getRect())) {
          this.player.meleeHitIds.add(pr);
          this.damageProp(pr, 2);
        }
      }
    }

    // Interactions (Buttons, Elevators, Checkpoint, Exit)
    this.handleInteractions(input.interactPressed);

    // Update enemies
    const pRect = this.player.getRect();
    for (let i = this.enemies.length - 1; i >= 0; i--) {
      const en = this.enemies[i];
      en.updateAI(dt, pRect, this.tilemap, doorSolids, (eBullets) => {
        this.audio.playShoot('enemy');
        for (let b = 0; b < eBullets.length; b++) {
          this.bullets.push(eBullets[b]);
        }
      });

      // Contact damage (not while player dashing)
      if (en.isAlive() && this.player.dashTimer <= 0 && aabbOverlap(pRect, en.getRect())) {
        const knockDir = this.player.x < en.x ? -1 : 1;
        this.damagePlayer(1, knockDir);
      }

      if (en.removed) {
        this.enemies.splice(i, 1);
      }
    }

    // Update props flash timers
    for (let i = 0; i < this.props.length; i++) {
      if (this.props[i].flashTimer > 0) this.props[i].flashTimer -= dt;
    }

    // Update pickups
    for (let i = this.pickups.length - 1; i >= 0; i--) {
      const pk = this.pickups[i];
      if (!pk.active) {
        this.pickups.splice(i, 1);
        continue;
      }
      if (aabbOverlap(pRect, pk.getRect())) {
        pk.active = false;
        this.audio.playPickup();
        if (pk.kind === 'health') {
          this.player.hp = Math.min(this.player.maxHp, this.player.hp + 2);
          this.addToast(pk.x, pk.y - 6, '+2 HP', PALETTE.neonGreen);
        } else {
          this.player.unlockOrAddAmmo(pk.kind);
          const label =
            pk.kind === 'shotgun' ? 'SHOTGUN!' : pk.kind === 'smg' ? 'SMG!' : '+AMMO';
          this.addToast(pk.x, pk.y - 6, label, PALETTE.neonYellow);
        }
        this.emitHud();
      }
    }

    // Update bullets & collisions
    this.updateBullets(dt, doorSolids);

    // Update steam vents, particles, toasts
    this.updateAmbientSteam(dt);
    this.particles.update(dt, (wx, wy) => this.tilemap.isSolidAtPixel(wx, wy));
    for (let i = this.toasts.length - 1; i >= 0; i--) {
      this.toasts[i].y -= 18 * dt;
      this.toasts[i].life -= dt;
      if (this.toasts[i].life <= 0) this.toasts.splice(i, 1);
    }

    // Smooth scrolling camera with horizontal lookahead
    const lookAhead = this.player.facing * 42;
    const targetCamX = this.clampCamX(
      this.player.x + this.player.w * 0.5 + lookAhead - INTERNAL_WIDTH * 0.45
    );
    const targetCamY = this.clampCamY(
      this.player.y + this.player.h * 0.5 - INTERNAL_HEIGHT * 0.56
    );
    const camLerp = 1 - Math.exp(-7.5 * dt);
    this.camX += (targetCamX - this.camX) * camLerp;
    this.camY += (targetCamY - this.camY) * camLerp;
  }

  private handleInteractions(interactPressed: boolean): void {
    const pRect = this.player.getRect();
    let prompt: string | null = null;
    let promptPos: { x: number; y: number } | null = null;

    // 1. Color-coded Button Terminals
    for (let i = 0; i < this.buttons.length; i++) {
      const btn = this.buttons[i];
      if (aabbOverlap(pRect, btn.getInteractRect())) {
        const door = this.doors.find((d) => d.color === btn.color);
        const canPress = !door?.isOpen || door.timedSeconds !== null;
        if (canPress) {
          prompt = `[E] ${btn.label}`;
          promptPos = { x: btn.x + 8, y: btn.y - 10 };
          if (interactPressed) {
            btn.trigger();
            this.audio.playButtonClick();
            door?.open((opening) => this.audio.playDoorSlide(opening));
            const c = DOOR_COLORS[btn.color].main;
            this.addToast(btn.x, btn.y - 12, `${DOOR_COLORS[btn.color].label} OPEN`, c);
            this.showBanner(
              door?.timedSeconds
                ? `${DOOR_COLORS[btn.color].label} DOOR OPEN — ${door.timedSeconds}S TIMER!`
                : `${DOOR_COLORS[btn.color].label} SECURITY DOOR UNLOCKED`
            );
            this.emitHud();
          }
        }
      }
    }

    // 2. Checkpoint Terminal on Floor 2
    const cpRect: Rect = {
      x: LEVEL_CHECKPOINT.col * TILE_SIZE - 10,
      y: LEVEL_CHECKPOINT.row * TILE_SIZE - 30,
      w: 38,
      h: 34,
    };
    if (aabbOverlap(pRect, cpRect)) {
      if (!this.checkpointSaved) {
        // Auto-activate when walking past OR via E
        this.checkpointSaved = true;
        this.audio.playPickup();
        this.addToast(cpRect.x + 8, cpRect.y, 'CHECKPOINT', PALETTE.neonGreen);
        this.showBanner('CHECKPOINT SAVED — FLOOR 2');
        this.emitHud();
      } else if (!prompt) {
        prompt = 'CHECKPOINT ACTIVE';
        promptPos = { x: cpRect.x + 16, y: cpRect.y - 4 };
      }
    }

    // 3. Elevators (E to trigger/call)
    for (let i = 0; i < this.elevators.length; i++) {
      const el = this.elevators[i];
      if (el.isPlayerOnTop(pRect)) {
        if (!prompt && !el.moving) {
          prompt = '[E] RIDE ELEVATOR';
          promptPos = { x: el.x + el.w * 0.5, y: el.y - 26 };
        }
        if (interactPressed) {
          el.toggleDirection(() => this.audio.playElevatorHum());
        }
      } else {
        const callFloorY = el.isNearCallSwitch(pRect);
        if (callFloorY !== null && Math.abs(el.y - callFloorY) > 4) {
          if (!prompt) {
            prompt = '[E] CALL ELEVATOR';
            promptPos = { x: this.player.x + 7, y: this.player.y - 12 };
          }
          if (interactPressed) {
            el.callToFloor(callFloorY, () => this.audio.playElevatorHum());
          }
        }
      }
    }

    // 4. Exit Extraction Airlock on Floor 3
    const exitRect: Rect = {
      x: LEVEL_EXIT.col * TILE_SIZE - 6,
      y: LEVEL_EXIT.row * TILE_SIZE - 42,
      w: 34,
      h: 44,
    };
    if (aabbOverlap(pRect, exitRect)) {
      prompt = '[E] EXTRACT';
      promptPos = { x: exitRect.x + 17, y: exitRect.y - 8 };
      if (interactPressed) {
        this.audio.playVictory();
        this.setPhase('victory');
        return;
      }
    }

    if (prompt !== this.promptText) {
      this.promptText = prompt;
      this.emitHud();
    }
    this.activePromptPos = promptPos;
  }

  private updateBullets(dt: number, doorSolids: Rect[]): void {
    const pRect = this.player.getRect();

    for (let i = this.bullets.length - 1; i >= 0; i--) {
      const b = this.bullets[i];
      b.update(dt);
      if (!b.active) {
        this.bullets.splice(i, 1);
        continue;
      }

      // World solid tile hit
      if (this.tilemap.isSolidAtPixel(b.x, b.y)) {
        this.particles.burst(b.x, b.y, 4, [b.color, PALETTE.white], 30, 80, 200, 'spark');
        this.bullets.splice(i, 1);
        continue;
      }

      // Closed security door blocks bullets
      const bRect = b.getRect();
      let blockedByDoor = false;
      for (let d = 0; d < doorSolids.length; d++) {
        if (aabbOverlap(bRect, doorSolids[d])) {
          this.particles.burst(b.x, b.y, 5, [b.color, PALETTE.white], 35, 90, 220, 'spark');
          blockedByDoor = true;
          break;
        }
      }
      if (blockedByDoor) {
        this.bullets.splice(i, 1);
        continue;
      }

      if (b.fromPlayer) {
        let consumed = false;
        // Enemy hit check
        for (let e = 0; e < this.enemies.length; e++) {
          const en = this.enemies[e];
          if (!en.isAlive()) continue;
          if (aabbOverlap(bRect, en.getRect())) {
            const knock = Math.sign(b.vx) * b.knockback;
            const killed = en.takeDamage(b.damage, knock);
            this.audio.playHit(killed);
            this.particles.burst(
              b.x,
              b.y,
              killed ? 14 : 6,
              [PALETTE.neonPink, PALETTE.white, '#ff9500'],
              40,
              130,
              320,
              'pixel'
            );
            if (killed) {
              this.handleEnemyKilled(en);
            }
            consumed = true;
            break;
          }
        }
        if (consumed) {
          this.bullets.splice(i, 1);
          continue;
        }

        // Destructible prop hit check
        for (let p = 0; p < this.props.length; p++) {
          const pr = this.props[p];
          if (!pr.active) continue;
          if (aabbOverlap(bRect, pr.getRect())) {
            this.damageProp(pr, b.damage);
            consumed = true;
            break;
          }
        }
        if (consumed) {
          this.bullets.splice(i, 1);
          continue;
        }
      } else {
        // Enemy bullet vs Player
        if (this.player.dashTimer <= 0 && aabbOverlap(bRect, pRect)) {
          const knockDir = b.vx >= 0 ? 1 : -1;
          this.damagePlayer(b.damage, knockDir);
          this.bullets.splice(i, 1);
          continue;
        }
      }
    }
  }

  private damagePlayer(amount: number, knockDir: number): void {
    if (!this.player.takeDamage(amount, knockDir)) return;
    this.damageTaken += amount;
    this.audio.playHit(true);
    this.hitstopTimer = 0.055;
    this.addTrauma(0.45);
    this.particles.burst(
      this.player.x + this.player.w * 0.5,
      this.player.y + this.player.h * 0.5,
      12,
      [PALETTE.neonRed, PALETTE.neonYellow, PALETTE.white],
      50,
      140,
      300,
      'pixel'
    );
    this.emitHud();
    if (this.player.hp <= 0) {
      this.audio.playExplosion();
      this.setPhase('defeat');
    }
  }

  private handleEnemyKilled(en: Enemy): void {
    this.kills++;
    this.hitstopTimer = 0.04;
    this.addTrauma(0.22);
    this.particles.burst(
      en.x + en.w * 0.5,
      en.y + en.h * 0.5,
      18,
      ['#991b2b', PALETTE.neonPink, PALETTE.neonAmber, '#3b4266'],
      55,
      165,
      360,
      'pixel'
    );
    this.particles.spawn({
      x: en.x + en.w * 0.5,
      y: en.y + en.h * 0.5,
      vx: 0,
      vy: 0,
      life: 0.14,
      size: 16,
      color: PALETTE.neonPink,
      style: 'glow',
    });

    if (!en.dropSpawned) {
      en.dropSpawned = true;
      const drop = en.rollDrop();
      if (drop) {
        this.pickups.push(new Pickup(drop, en.x, en.y + en.h - 12));
      }
    }
    this.emitHud();
  }

  private damageProp(pr: Prop, dmg: number): void {
    pr.hp -= dmg;
    pr.flashTimer = 0.05;
    this.audio.playHit(false);
    this.particles.burst(
      pr.x + pr.w * 0.5,
      pr.y + pr.h * 0.5,
      5,
      pr.kind === 'crate' ? ['#9a6b42', '#d4a373'] : [PALETTE.neonCyan, '#64748b'],
      30,
      90,
      260,
      'pixel'
    );

    if (pr.hp <= 0) {
      pr.active = false;
      this.propsDestroyed++;
      if (pr.kind === 'barrel') {
        this.triggerExplosion(pr.x + pr.w * 0.5, pr.y + pr.h * 0.5);
      } else if (pr.drop) {
        this.pickups.push(new Pickup(pr.drop, pr.x, pr.y + pr.h - 12));
      }
    }
  }

  private triggerExplosion(cx: number, cy: number): void {
    this.audio.playExplosion();
    this.hitstopTimer = 0.065;
    this.addTrauma(0.65);

    this.particles.burst(
      cx,
      cy,
      26,
      [PALETTE.neonYellow, PALETTE.neonAmber, PALETTE.neonRed, PALETTE.white],
      70,
      210,
      240,
      'pixel'
    );
    this.particles.burst(cx, cy, 10, ['#475569', '#1e293b'], 25, 70, -30, 'smoke');
    this.particles.spawn({
      x: cx,
      y: cy,
      vx: 0,
      vy: 0,
      life: 0.22,
      size: 28,
      color: PALETTE.neonAmber,
      style: 'glow',
    });

    const blastRadius = 56;
    for (let i = 0; i < this.enemies.length; i++) {
      const en = this.enemies[i];
      if (!en.isAlive()) continue;
      const ex = en.x + en.w * 0.5;
      const ey = en.y + en.h * 0.5;
      if (Math.hypot(ex - cx, ey - cy) <= blastRadius) {
        const killed = en.takeDamage(4, Math.sign(ex - cx) * 180);
        if (killed) this.handleEnemyKilled(en);
      }
    }

    const px = this.player.x + this.player.w * 0.5;
    const py = this.player.y + this.player.h * 0.5;
    if (Math.hypot(px - cx, py - cy) <= blastRadius * 0.8) {
      this.damagePlayer(1, px >= cx ? 1 : -1);
    }
  }

  private updateAmbientSteam(dt: number): void {
    this.steamTimer += dt;
    if (this.steamTimer < 0.09) return;
    this.steamTimer = 0;
    for (let i = 0; i < STEAM_VENTS.length; i++) {
      const v = STEAM_VENTS[i];
      const vx = v.col * TILE_SIZE + 8;
      const vy = v.row * TILE_SIZE;
      if (Math.abs(vx - (this.camX + INTERNAL_WIDTH * 0.5)) > INTERNAL_WIDTH) continue;
      this.particles.spawn({
        x: vx + (Math.random() - 0.5) * 4,
        y: vy,
        vx: (Math.random() - 0.5) * 12,
        vy: v.dir === 'down' ? 18 + Math.random() * 14 : -(20 + Math.random() * 16),
        life: 0.55 + Math.random() * 0.4,
        size: 3,
        color: '#64748b',
        style: 'smoke',
      });
    }
  }

  private addToast(x: number, y: number, text: string, color: string): void {
    this.toasts.push({ x, y, text, color, life: 1.15 });
  }

  private addTrauma(amount: number): void {
    this.trauma = Math.min(1, this.trauma + amount);
  }

  private clampCamX(x: number): number {
    return Math.max(0, Math.min(this.tilemap.worldWidth - INTERNAL_WIDTH, x));
  }

  private clampCamY(y: number): number {
    return Math.max(0, Math.min(this.tilemap.worldHeight - INTERNAL_HEIGHT, y));
  }

  public getFloorNumber(): 1 | 2 | 3 {
    const py = this.player.y + this.player.h;
    if (py <= 13 * TILE_SIZE) return 3;
    if (py <= 25 * TILE_SIZE) return 2;
    return 1;
  }

  public getHudSnapshot(): HudSnapshot {
    return {
      phase: this.phase,
      hp: this.player.hp,
      maxHp: this.player.maxHp,
      weapon: this.player.weapon,
      unlockedWeapons: [...this.player.unlockedWeapons],
      ammo: { ...this.player.ammo },
      kills: this.kills,
      totalEnemies: this.totalEnemies,
      propsDestroyed: this.propsDestroyed,
      elapsedTime: this.runElapsed,
      damageTaken: this.damageTaken,
      checkpointSaved: this.checkpointSaved,
      doors: this.doors.map((d) => ({
        color: d.color,
        isOpen: d.isOpen,
        timerRemaining: d.timedSeconds !== null && d.isOpen ? d.timerRemaining : null,
        timerTotal: d.timedSeconds,
      })),
      promptText: this.promptText,
      bannerText: this.bannerText,
      crtEnabled: this.crtEnabled,
      muted: this.audio.isMuted(),
      floorNumber: this.getFloorNumber(),
    };
  }

  private emitHud(): void {
    this.onHudChange?.(this.getHudSnapshot());
  }

  public render(): void {
    const ctx = this.ctx;
    if (!ctx) return;
    ctx.imageSmoothingEnabled = false;

    const shakeMag = this.trauma * this.trauma * 7;
    const shakeX = shakeMag > 0.1 ? Math.round((Math.random() * 2 - 1) * shakeMag) : 0;
    const shakeY = shakeMag > 0.1 ? Math.round((Math.random() * 2 - 1) * shakeMag) : 0;
    const rx = Math.round(this.camX) + shakeX;
    const ry = Math.round(this.camY) + shakeY;

    // 1. Background & Parallax City
    this.background.renderBackdrop(ctx, rx, ry, INTERNAL_WIDTH, INTERNAL_HEIGHT, this.simTime);
    this.background.renderSpecialStations(ctx, rx, ry, this.simTime, this.checkpointSaved);

    // 2. Doors & Buttons & Elevators
    for (let i = 0; i < this.buttons.length; i++) {
      this.buttons[i].render(ctx, rx, ry, this.simTime);
    }
    for (let i = 0; i < this.doors.length; i++) {
      this.doors[i].render(ctx, rx, ry);
    }
    for (let i = 0; i < this.elevators.length; i++) {
      this.elevators[i].render(ctx, rx, ry, this.simTime);
    }

    // 3. Solid & One-Way Tiles
    this.tilemap.renderVisibleTiles(ctx, rx, ry, INTERNAL_WIDTH, INTERNAL_HEIGHT);

    // 4. Props & Pickups
    for (let i = 0; i < this.props.length; i++) {
      this.props[i].render(ctx, rx, ry, this.simTime);
    }
    for (let i = 0; i < this.pickups.length; i++) {
      this.pickups[i].render(ctx, rx, ry, this.simTime);
    }

    // 5. Enemies & Player (hidden on title tour)
    for (let i = 0; i < this.enemies.length; i++) {
      this.enemies[i].render(ctx, rx, ry);
    }
    if (this.phase !== 'title') {
      this.player.render(ctx, rx, ry, this.simTime);
    }

    // 6. Bullets & Particles
    for (let i = 0; i < this.bullets.length; i++) {
      this.bullets[i].render(ctx, rx, ry);
    }
    this.particles.render(ctx, rx, ry);

    // 7. Additive neon & muzzle glow pass
    this.background.renderAdditiveGlow(ctx, rx, ry, this.simTime);
    this.particles.renderGlow(ctx, rx, ry);

    // 8. World-space interact prompt & floating toasts
    if (this.phase === 'playing' && this.promptText && this.activePromptPos) {
      const px = Math.round(this.activePromptPos.x - rx);
      const py = Math.round(this.activePromptPos.y - ry);
      ctx.font = 'bold 7px "JetBrains Mono", monospace';
      ctx.textAlign = 'center';
      const w = this.promptText.length * 5 + 8;
      ctx.fillStyle = 'rgba(7, 8, 17, 0.9)';
      ctx.fillRect(px - (w >> 1), py - 10, w, 11);
      ctx.strokeStyle = PALETTE.neonCyan;
      ctx.lineWidth = 1;
      ctx.strokeRect(px - (w >> 1) + 0.5, py - 9.5, w - 1, 10);
      ctx.fillStyle = PALETTE.white;
      ctx.fillText(this.promptText, px, py - 8);
      ctx.textAlign = 'left';
    }

    for (let i = 0; i < this.toasts.length; i++) {
      const t = this.toasts[i];
      ctx.globalAlpha = Math.min(1, t.life * 1.6);
      ctx.font = 'bold 7px "JetBrains Mono", monospace';
      ctx.fillStyle = t.color;
      ctx.fillText(t.text, Math.round(t.x - rx), Math.round(t.y - ry));
    }
    ctx.globalAlpha = 1;

    // 9. Optional subtle scanline & vignette CRT pass
    if (this.crtEnabled) {
      ctx.fillStyle = 'rgba(0, 0, 0, 0.16)';
      for (let y = 0; y < INTERNAL_HEIGHT; y += 2) {
        ctx.fillRect(0, y, INTERNAL_WIDTH, 1);
      }
      // Subtle edge vignette
      ctx.fillStyle = 'rgba(4, 5, 12, 0.35)';
      ctx.fillRect(0, 0, INTERNAL_WIDTH, 6);
      ctx.fillRect(0, INTERNAL_HEIGHT - 6, INTERNAL_WIDTH, 6);
      ctx.fillRect(0, 0, 6, INTERNAL_HEIGHT);
      ctx.fillRect(INTERNAL_WIDTH - 6, 0, 6, INTERNAL_HEIGHT);
    }
  }
}
