import type { WeaponConfig, WeaponId, DoorColor } from './types';

export const INTERNAL_WIDTH = 480;
export const INTERNAL_HEIGHT = 270;
export const TILE_SIZE = 16;
export const FIXED_DT = 1 / 60;
export const MAX_FRAME_DT = 0.05;

export const PHYSICS = {
  gravity: 780,
  maxFallSpeed: 380,
  playerWalkSpeed: 138,
  playerAccel: 1450,
  playerFriction: 1650,
  playerJumpVel: -275,
  jumpCutMultiplier: 0.46,
  coyoteTime: 0.11,
  jumpBuffer: 0.12,
  dashSpeed: 295,
  dashDuration: 0.18,
  dashCooldown: 0.45,
  playerMaxHp: 5,
  playerInvulnDuration: 1.15,
  playerStandW: 14,
  playerStandH: 28,
  playerCrouchH: 17,
} as const;

// Sprite crop measurements from /assets/aistudio/Char_2322f0be.png (100x100)
export const PLAYER_SPRITE_CROP = {
  srcPath: '/assets/aistudio/Char_2322f0be.png',
  sx: 19,
  sy: 4,
  sw: 78,
  sh: 89,
  drawW: 30,
  drawH: 34,
} as const;

export const PALETTE = {
  bgDeep: '#070811',
  bgIndigo: '#0d1021',
  bgMid: '#151932',
  steelDark: '#1e2440',
  steelMid: '#2e3659',
  steelLight: '#4d5885',
  steelEdge: '#7785b8',
  neonPink: '#ff2a85',
  neonCyan: '#00f0ff',
  neonGreen: '#39ff14',
  neonAmber: '#ff9500',
  neonRed: '#ff2b45',
  neonYellow: '#ffe600',
  white: '#f8fafc',
} as const;

export const DOOR_COLORS: Record<DoorColor, { main: string; glow: string; dark: string; label: string }> = {
  red: { main: '#ff2b45', glow: '#ff6b7d', dark: '#5e101c', label: 'RED' },
  blue: { main: '#00d4ff', glow: '#7ef0ff', dark: '#0c4359', label: 'BLUE' },
  green: { main: '#39ff14', glow: '#9bff87', dark: '#104f18', label: 'GREEN' },
};

export const WEAPONS: Record<WeaponId, WeaponConfig> = {
  pistol: {
    id: 'pistol',
    name: '9MM VIPER',
    shortName: 'PISTOL',
    fireRate: 0.21,
    damage: 1,
    bulletSpeed: 390,
    pellets: 1,
    spreadRad: 0.02,
    knockback: 75,
    muzzleColor: '#ffe600',
    bulletColor: '#ffe600',
    recoil: 2.5,
    maxAmmo: Infinity,
    auto: false,
  },
  shotgun: {
    id: 'shotgun',
    name: 'CERBERUS-12',
    shortName: 'SHOTGUN',
    fireRate: 0.56,
    damage: 1,
    bulletSpeed: 350,
    pellets: 5,
    spreadRad: 0.24,
    knockback: 140,
    muzzleColor: '#ff9500',
    bulletColor: '#ff9500',
    recoil: 5.5,
    maxAmmo: 16,
    auto: false,
  },
  smg: {
    id: 'smg',
    name: 'KINETIC-MP9',
    shortName: 'SMG',
    fireRate: 0.085,
    damage: 1,
    bulletSpeed: 420,
    pellets: 1,
    spreadRad: 0.085,
    knockback: 45,
    muzzleColor: '#00f0ff',
    bulletColor: '#00f0ff',
    recoil: 1.6,
    maxAmmo: 80,
    auto: true,
  },
};
