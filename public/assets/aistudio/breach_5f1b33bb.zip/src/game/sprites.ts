import { PALETTE } from './config';
import type { AimMode, EnemyAIState, WeaponId } from './types';

export type HackerAnimState = 'idle' | 'run' | 'jump' | 'crouch' | 'dash';

const H_COLORS = {
  outline: '#05060c',
  coatDark: '#12172b',
  coatMid: '#1f2847',
  coatLight: '#334270',
  trimCyan: '#00f0ff',
  trimCyanDim: '#008899',
  shirtDark: '#5e1133',
  shirtBright: '#ff2a85',
  skin: '#d9a489',
  skinShadow: '#a66e56',
  hair: '#171326',
  hairHi: '#3d2f63',
  pantsDark: '#0e1120',
  pantsMid: '#1e243d',
  bootDark: '#0b0d17',
  bootHi: '#4a5780',
  packBody: '#20263f',
  packLed1: '#39ff14',
  packLed2: '#ff2a85',
  gunMetal: '#5a688c',
  gunDark: '#262d42',
  gunHi: '#9fb0d6',
};

function drawOutlinedRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  fill: string,
  outline = H_COLORS.outline
): void {
  ctx.fillStyle = outline;
  ctx.fillRect(x - 1, y - 1, w + 2, h + 2);
  ctx.fillStyle = fill;
  ctx.fillRect(x, y, w, h);
}

/**
 * Renders the custom-drawn Cyberpunk Hacker protagonist with 6-frame animations
 * for idle, run, jump, crouch, and 5-frame dash, plus articulated angled weapons.
 */
export function renderHackerSprite(
  ctx: CanvasRenderingContext2D,
  opts: {
    footX: number;
    footY: number;
    facing: 1 | -1;
    animState: HackerAnimState;
    frameIdx: number; // 0..5
    aimMode: AimMode;
    weapon: WeaponId;
    recoil: number;
    scaleX: number;
    scaleY: number;
    whiteFlash?: boolean;
  }
): void {
  const { footX, footY, facing, animState, frameIdx, aimMode, weapon, recoil, scaleX, scaleY, whiteFlash } = opts;
  const f = ((frameIdx % 6) + 6) % 6;

  ctx.save();
  ctx.translate(Math.round(footX), Math.round(footY));
  ctx.scale(facing * scaleX, scaleY);

  if (animState === 'dash') {
    // 5-frame cyber-dash roll / low aero slide
    const df = f % 5;
    const rollOffsetY = df === 1 || df === 2 ? -3 : -1;
    const stretch = df === 2 ? 3 : 1;
    // Cyber slide silhouette
    drawOutlinedRect(ctx, -9 - stretch, -15 + rollOffsetY, 18 + stretch * 2, 11, whiteFlash ? PALETTE.white : H_COLORS.coatMid);
    if (!whiteFlash) {
      ctx.fillStyle = H_COLORS.coatDark;
      ctx.fillRect(-8 - stretch, -10 + rollOffsetY, 16 + stretch * 2, 5);
      // Glowing cyber visor streak
      ctx.fillStyle = H_COLORS.trimCyan;
      ctx.fillRect(2, -13 + rollOffsetY, 7 + df, 2);
      // Trailing coat tail
      ctx.fillStyle = H_COLORS.shirtBright;
      ctx.fillRect(-10 - stretch, -12 + rollOffsetY, 4, 3);
      // Tucked boots
      ctx.fillStyle = H_COLORS.bootDark;
      ctx.fillRect(-5, -5, 11, 5);
      ctx.fillStyle = H_COLORS.trimCyan;
      ctx.fillRect(-4, -1, 9, 1);
    }
    ctx.restore();
    return;
  }

  if (animState === 'crouch') {
    // 6-frame crouch animation (compact tactical stance ~18px tall)
    const breathe = f === 2 || f === 3 ? 1 : 0;
    const visorScan = f;
    const bodyY = -17 + breathe;

    // Cyber-deck backpack
    drawOutlinedRect(ctx, -7, bodyY + 3, 4, 8, whiteFlash ? PALETTE.white : H_COLORS.packBody);
    if (!whiteFlash) {
      ctx.fillStyle = f % 2 === 0 ? H_COLORS.packLed1 : H_COLORS.trimCyan;
      ctx.fillRect(-6, bodyY + 5, 2, 2);
    }

    // Kneeling legs & boots
    drawOutlinedRect(ctx, -5, -7, 11, 7, whiteFlash ? PALETTE.white : H_COLORS.pantsDark);
    if (!whiteFlash) {
      ctx.fillStyle = H_COLORS.bootDark;
      ctx.fillRect(-5, -3, 5, 3);
      ctx.fillRect(2, -3, 5, 3);
      ctx.fillStyle = H_COLORS.trimCyan;
      ctx.fillRect(2, -1, 5, 1);
    }

    // Draped trenchcoat torso
    drawOutlinedRect(ctx, -5, bodyY + 3, 10, 9 - breathe, whiteFlash ? PALETTE.white : H_COLORS.coatMid);
    if (!whiteFlash) {
      ctx.fillStyle = H_COLORS.coatDark;
      ctx.fillRect(-5, bodyY + 8, 10, 4 - breathe);
      ctx.fillStyle = H_COLORS.shirtBright;
      ctx.fillRect(-1, bodyY + 4, 4, 4);
      ctx.fillStyle = H_COLORS.trimCyan;
      ctx.fillRect(-4, bodyY + 3, 8, 1);
    }

    // Head + Cyber Visor
    renderHackerHead(ctx, -4, bodyY - 5, visorScan, whiteFlash);
    // Articulated weapon arm
    renderHackerWeaponArm(ctx, 1, bodyY + 5, aimMode, weapon, recoil, whiteFlash);

    ctx.restore();
    return;
  }

  // Standing / Idle / Run / Jump calculations (6 frames each)
  let bodyBob = 0;
  let torsoLean = 0;
  let coatFlare = 0;
  let leftLegX = -3;
  let leftLegY = -10;
  let rightLegX = 1;
  let rightLegY = -10;
  let leftKneeBent = false;
  let rightKneeBent = false;

  if (animState === 'idle') {
    // 6-frame breathing & subtle cyber-pack shift
    const bobCycle = [0, 0, 1, 1, 1, 0];
    bodyBob = bobCycle[f];
    coatFlare = f === 3 || f === 4 ? 1 : 0;
  } else if (animState === 'run') {
    // 6-frame articulated run cycle
    const runLegs: Array<[number, number, number, number, number, number]> = [
      // [bob, lx, ly, rx, ry, flare]
      [-1, -5, -10, 3, -11, 3],
      [1, -2, -9, 2, -10, 2],
      [0, 2, -11, -3, -9, 3],
      [-1, 4, -11, -5, -10, 4],
      [1, 1, -10, -2, -9, 2],
      [0, -3, -9, 1, -11, 3],
    ];
    const k = runLegs[f];
    bodyBob = k[0];
    leftLegX = k[1];
    leftLegY = k[2];
    rightLegX = k[3];
    rightLegY = k[4];
    coatFlare = k[5];
    torsoLean = 1;
  } else if (animState === 'jump') {
    // 6-frame jump / air cycle (mapped from vy & air time)
    const jumpPose: Array<[number, number, number, number, number, boolean, boolean]> = [
      [1, -4, -9, 2, -9, true, true],     // 0: launch coil
      [-2, -3, -10, 2, -12, false, true], // 1: burst up
      [-1, -4, -12, 2, -13, true, true],  // 2: mid rise
      [0, -4, -11, 2, -12, true, true],   // 3: apex tuck
      [0, -5, -10, 3, -10, false, false], // 4: descent flare
      [2, -4, -8, 2, -8, true, true],     // 5: landing brace
    ];
    const jp = jumpPose[f];
    bodyBob = jp[0];
    leftLegX = jp[1];
    leftLegY = jp[2];
    rightLegX = jp[3];
    rightLegY = jp[4];
    leftKneeBent = jp[5];
    rightKneeBent = jp[6];
    coatFlare = f >= 2 && f <= 4 ? 4 : 2;
  }

  const torsoY = -23 + bodyBob;

  // 1. Cyber-deck Backpack (behind torso)
  drawOutlinedRect(ctx, -7 + torsoLean, torsoY + 2, 4, 9, whiteFlash ? PALETTE.white : H_COLORS.packBody);
  if (!whiteFlash) {
    ctx.fillStyle = f % 3 === 0 ? H_COLORS.packLed1 : f % 3 === 1 ? H_COLORS.trimCyan : H_COLORS.packLed2;
    ctx.fillRect(-6 + torsoLean, torsoY + 4, 2, 2);
    ctx.fillStyle = H_COLORS.trimCyanDim;
    ctx.fillRect(-6 + torsoLean, torsoY + 8, 2, 2);
  }

  // 2. Back Leg
  const backH = leftKneeBent ? 8 : 10;
  drawOutlinedRect(ctx, leftLegX, leftLegY, 4, backH, whiteFlash ? PALETTE.white : H_COLORS.pantsDark);
  if (!whiteFlash) {
    ctx.fillStyle = H_COLORS.bootDark;
    ctx.fillRect(leftLegX, leftLegY + backH - 4, 5, 4);
    ctx.fillStyle = H_COLORS.trimCyanDim;
    ctx.fillRect(leftLegX, leftLegY + backH - 1, 4, 1);
  }

  // 3. Flowing Coat Tail (behind legs)
  if (!whiteFlash) {
    ctx.fillStyle = H_COLORS.outline;
    ctx.fillRect(-7 - coatFlare, torsoY + 9, 6 + coatFlare, 10);
    ctx.fillStyle = H_COLORS.coatDark;
    ctx.fillRect(-6 - coatFlare, torsoY + 10, 5 + coatFlare, 8);
    ctx.fillStyle = H_COLORS.trimCyanDim;
    ctx.fillRect(-6 - coatFlare, torsoY + 17, 4 + coatFlare, 1);
  }

  // 4. Front Leg
  const frontH = rightKneeBent ? 8 : 10;
  drawOutlinedRect(ctx, rightLegX, rightLegY, 4, frontH, whiteFlash ? PALETTE.white : H_COLORS.pantsMid);
  if (!whiteFlash) {
    ctx.fillStyle = H_COLORS.bootDark;
    ctx.fillRect(rightLegX, rightLegY + frontH - 4, 5, 4);
    ctx.fillStyle = H_COLORS.bootHi;
    ctx.fillRect(rightLegX + 1, rightLegY + frontH - 4, 2, 2);
    ctx.fillStyle = H_COLORS.trimCyan;
    ctx.fillRect(rightLegX, rightLegY + frontH - 1, 5, 1);
  }

  // 5. Cyber-Trenchcoat Torso
  drawOutlinedRect(ctx, -4 + torsoLean, torsoY, 9, 13, whiteFlash ? PALETTE.white : H_COLORS.coatMid);
  if (!whiteFlash) {
    // Inner neon undershirt chest armor
    ctx.fillStyle = H_COLORS.shirtDark;
    ctx.fillRect(-1 + torsoLean, torsoY + 2, 5, 8);
    ctx.fillStyle = H_COLORS.shirtBright;
    ctx.fillRect(0 + torsoLean, torsoY + 3, 3, 4);
    // Coat lapels & glowing cyan collar
    ctx.fillStyle = H_COLORS.coatLight;
    ctx.fillRect(-4 + torsoLean, torsoY, 3, 11);
    ctx.fillStyle = H_COLORS.trimCyan;
    ctx.fillRect(-4 + torsoLean, torsoY, 8, 2);
    // Belt buckle
    ctx.fillStyle = H_COLORS.outline;
    ctx.fillRect(-4 + torsoLean, torsoY + 10, 9, 2);
    ctx.fillStyle = PALETTE.neonYellow;
    ctx.fillRect(1 + torsoLean, torsoY + 10, 2, 2);
  }

  // 6. Hacker Head + Glowing AR Visor
  renderHackerHead(ctx, -4 + torsoLean, torsoY - 9, f, whiteFlash);

  // 7. Articulated Weapon Arm (supports 0°, ±45°, ±90°)
  renderHackerWeaponArm(ctx, 1 + torsoLean, torsoY + 4, aimMode, weapon, recoil, whiteFlash);

  ctx.restore();
}

function renderHackerHead(
  ctx: CanvasRenderingContext2D,
  hx: number,
  hy: number,
  frameIdx: number,
  whiteFlash?: boolean
): void {
  // Head silhouette
  drawOutlinedRect(ctx, hx, hy, 9, 9, whiteFlash ? PALETTE.white : H_COLORS.skin);
  if (whiteFlash) return;

  // Shadow cheek & neck
  ctx.fillStyle = H_COLORS.skinShadow;
  ctx.fillRect(hx, hy + 6, 4, 3);

  // Cyberpunk haircut + neural antenna jack
  ctx.fillStyle = H_COLORS.hair;
  ctx.fillRect(hx - 1, hy - 2, 10, 4);
  ctx.fillRect(hx - 1, hy + 1, 3, 5);
  ctx.fillStyle = H_COLORS.hairHi;
  ctx.fillRect(hx + 1, hy - 2, 5, 2);
  // Neural jack antenna on ear
  ctx.fillStyle = H_COLORS.trimCyan;
  ctx.fillRect(hx - 1, hy + 3, 1, 3);

  // Glowing Cyan AR Cyber-Visor
  ctx.fillStyle = H_COLORS.outline;
  ctx.fillRect(hx + 2, hy + 2, 8, 4);
  ctx.fillStyle = H_COLORS.trimCyan;
  ctx.fillRect(hx + 3, hy + 3, 6, 2);
  // Animated white scan glint moving across visor
  const glintX = hx + 3 + (frameIdx % 4);
  ctx.fillStyle = PALETTE.white;
  ctx.fillRect(glintX, hy + 3, 2, 1);
}

function renderHackerWeaponArm(
  ctx: CanvasRenderingContext2D,
  shoulderX: number,
  shoulderY: number,
  aimMode: AimMode,
  weapon: WeaponId,
  recoil: number,
  whiteFlash?: boolean
): void {
  const angleMap: Record<AimMode, number> = {
    straight: 0,
    upDiag: -Math.PI / 4,
    up: -Math.PI / 2,
    downDiag: Math.PI / 4,
    down: Math.PI / 2,
  };

  ctx.save();
  ctx.translate(shoulderX, shoulderY);
  ctx.rotate(angleMap[aimMode]);
  ctx.translate(-Math.round(recoil * 0.7), 0);

  // Cybernetic forearm + glove
  drawOutlinedRect(ctx, -1, -2, 6, 4, whiteFlash ? PALETTE.white : H_COLORS.coatLight);
  if (!whiteFlash) {
    ctx.fillStyle = H_COLORS.trimCyan;
    ctx.fillRect(2, -2, 1, 4);
    ctx.fillStyle = H_COLORS.skinShadow;
    ctx.fillRect(4, -1, 2, 3);
  }

  // Weapon silhouette
  if (weapon === 'pistol') {
    drawOutlinedRect(ctx, 5, -3, 7, 3, whiteFlash ? PALETTE.white : H_COLORS.gunMetal);
    if (!whiteFlash) {
      ctx.fillStyle = H_COLORS.gunHi;
      ctx.fillRect(5, -3, 6, 1);
      ctx.fillStyle = PALETTE.neonYellow;
      ctx.fillRect(10, -2, 2, 1);
      ctx.fillStyle = H_COLORS.gunDark;
      ctx.fillRect(5, 0, 2, 3);
    }
  } else if (weapon === 'shotgun') {
    drawOutlinedRect(ctx, 3, -3, 12, 4, whiteFlash ? PALETTE.white : H_COLORS.gunDark);
    if (!whiteFlash) {
      ctx.fillStyle = H_COLORS.gunHi;
      ctx.fillRect(5, -3, 10, 2);
      ctx.fillStyle = PALETTE.neonAmber;
      ctx.fillRect(7, -1, 5, 2);
      ctx.fillStyle = '#7c4a24';
      ctx.fillRect(2, -1, 3, 3);
    }
  } else {
    // SMG
    drawOutlinedRect(ctx, 4, -3, 10, 3, whiteFlash ? PALETTE.white : H_COLORS.gunDark);
    if (!whiteFlash) {
      ctx.fillStyle = PALETTE.neonCyan;
      ctx.fillRect(6, -3, 6, 1);
      ctx.fillStyle = H_COLORS.gunHi;
      ctx.fillRect(5, -2, 8, 2);
      ctx.fillStyle = H_COLORS.gunMetal;
      ctx.fillRect(8, 0, 2, 4);
    }
  }

  ctx.restore();
}

/**
 * Renders 6-frame animated Gang Thug sprite with neon mohawk, leather vest, and pistol.
 */
export function renderThugSprite(
  ctx: CanvasRenderingContext2D,
  sx: number,
  sy: number,
  w: number,
  h: number,
  facing: 1 | -1,
  state: EnemyAIState,
  frameIdx: number,
  whiteFlash: boolean
): void {
  const f = ((frameIdx % 6) + 6) % 6;
  ctx.save();
  ctx.translate(Math.round(sx + w * 0.5), Math.round(sy + h));
  ctx.scale(facing, 1);

  if (whiteFlash) {
    drawOutlinedRect(ctx, -7, -26, 14, 26, PALETTE.white);
    ctx.restore();
    return;
  }

  const walkOffsets = [-1, 0, 1, 0, -1, 0];
  const legOffsets = [-3, -1, 2, 3, 1, -2];
  const isMoving = state === 'patrol' || state === 'retreat';
  const bob = isMoving ? walkOffsets[f] : f === 2 || f === 3 ? 1 : 0;
  const stride = isMoving ? legOffsets[f] : 0;
  const crouch = state === 'alert' ? 2 : 0;

  // Legs
  drawOutlinedRect(ctx, -5 + stride, -9, 4, 9, '#191d30');
  drawOutlinedRect(ctx, 1 - stride, -9, 4, 9, '#252b47');
  ctx.fillStyle = '#0a0c15';
  ctx.fillRect(-5 + stride, -3, 5, 3);
  ctx.fillRect(1 - stride, -3, 5, 3);

  // Leather gang jacket
  drawOutlinedRect(ctx, -6, -19 + bob + crouch, 12, 11 - crouch, '#3b1236');
  ctx.fillStyle = '#631d59';
  ctx.fillRect(-4, -18 + bob + crouch, 5, 8 - crouch);
  ctx.fillStyle = PALETTE.neonPink;
  ctx.fillRect(-5, -18 + bob + crouch, 10, 2);

  // Head + Mohawk
  drawOutlinedRect(ctx, -4, -25 + bob + crouch, 8, 6, '#d99b78');
  ctx.fillStyle = '#070811';
  ctx.fillRect(0, -23 + bob + crouch, 4, 2); // Shades
  // Animated neon mohawk spikes
  const spikeH = f % 2 === 0 ? 4 : 3;
  ctx.fillStyle = PALETTE.neonPink;
  ctx.fillRect(-3, -26 - spikeH + bob + crouch + 2, 5, spikeH);
  ctx.fillStyle = '#ff99c8';
  ctx.fillRect(-2, -26 - spikeH + bob + crouch + 2, 2, 1);

  // Extended Pistol Arm
  const recoil = state === 'attack' && f % 2 === 0 ? -2 : 0;
  drawOutlinedRect(ctx, 3 + recoil, -19 + bob + crouch, 8, 3, '#6f7c9e');
  ctx.fillStyle = '#9aa8cc';
  ctx.fillRect(4 + recoil, -19 + bob + crouch, 6, 1);

  ctx.restore();
}

/**
 * Renders 6-frame animated Heavy Shotgunner armored enforcer.
 */
export function renderHeavySprite(
  ctx: CanvasRenderingContext2D,
  sx: number,
  sy: number,
  w: number,
  h: number,
  facing: 1 | -1,
  state: EnemyAIState,
  frameIdx: number,
  whiteFlash: boolean
): void {
  const f = ((frameIdx % 6) + 6) % 6;
  ctx.save();
  ctx.translate(Math.round(sx + w * 0.5), Math.round(sy + h));
  ctx.scale(facing, 1);

  if (whiteFlash) {
    drawOutlinedRect(ctx, -9, -30, 18, 30, PALETTE.white);
    ctx.restore();
    return;
  }

  const stomp = state === 'patrol' || state === 'retreat' ? [0, -1, 0, 1, 0, -1][f] : 0;
  const stride = state === 'patrol' || state === 'retreat' ? [-2, -1, 1, 2, 1, -1][f] : 0;

  // Heavy boots
  drawOutlinedRect(ctx, -7 + stride, -10, 5, 10, '#1c2138');
  drawOutlinedRect(ctx, 2 - stride, -10, 5, 10, '#2a3152');
  ctx.fillStyle = '#5a648a';
  ctx.fillRect(-7 + stride, -4, 6, 4);
  ctx.fillRect(2 - stride, -4, 6, 4);

  // Armored chest & pauldrons
  drawOutlinedRect(ctx, -9, -23 + stomp, 18, 14, '#363d61');
  ctx.fillStyle = '#505a8a';
  ctx.fillRect(-8, -22 + stomp, 16, 4);
  ctx.fillStyle = PALETTE.neonAmber;
  ctx.fillRect(-5, -18 + stomp, 10, 3);
  // Reactor core pulse
  ctx.fillStyle = f % 2 === 0 ? PALETTE.neonYellow : PALETTE.neonAmber;
  ctx.fillRect(-1, -14 + stomp, 3, 3);

  // Helmet + Red Visor slit
  drawOutlinedRect(ctx, -6, -30 + stomp, 12, 8, '#1b2038');
  ctx.fillStyle = '#3b4266';
  ctx.fillRect(-5, -29 + stomp, 10, 2);
  ctx.fillStyle = state === 'alert' ? PALETTE.neonYellow : PALETTE.neonRed;
  ctx.fillRect(0, -26 + stomp, 5, 2);

  // Heavy Pump Shotgun
  const recoil = state === 'attack' ? -2 : 0;
  drawOutlinedRect(ctx, 2 + recoil, -18 + stomp, 13, 4, '#5a668a');
  ctx.fillStyle = PALETTE.neonAmber;
  ctx.fillRect(11 + recoil, -18 + stomp, 3, 2);

  ctx.restore();
}

/**
 * Renders 6-frame Security Drone with spinning twin rotors & thruster flame.
 */
export function renderDroneSprite(
  ctx: CanvasRenderingContext2D,
  sx: number,
  sy: number,
  facing: 1 | -1,
  state: EnemyAIState,
  frameIdx: number,
  whiteFlash: boolean
): void {
  const f = ((frameIdx % 6) + 6) % 6;
  ctx.save();
  ctx.translate(Math.round(sx + 8), Math.round(sy + 7));
  ctx.scale(facing, 1);

  if (whiteFlash) {
    drawOutlinedRect(ctx, -8, -7, 16, 14, PALETTE.white);
    ctx.restore();
    return;
  }

  // Twin spinning rotors (6-frame width oscillation)
  const rw = [14, 10, 4, 14, 8, 4][f];
  ctx.fillStyle = PALETTE.neonCyan;
  ctx.fillRect(-Math.floor(rw / 2), -8, rw, 2);
  ctx.fillStyle = PALETTE.white;
  ctx.fillRect(-2, -8, 4, 1);

  // Thruster glow underneath
  ctx.fillStyle = f % 2 === 0 ? PALETTE.neonAmber : PALETTE.neonCyan;
  ctx.fillRect(-3, 5, 6, f % 3 === 0 ? 3 : 2);

  // Chassis
  drawOutlinedRect(ctx, -7, -5, 14, 10, '#242b47');
  ctx.fillStyle = '#4d5885';
  ctx.fillRect(-5, -4, 10, 3);
  ctx.fillStyle = '#121629';
  ctx.fillRect(-5, 0, 10, 4);

  // Scanning lens
  ctx.fillStyle = state === 'alert' ? PALETTE.neonPink : PALETTE.neonCyan;
  ctx.fillRect(1, 0, 5, 3);
  ctx.fillStyle = PALETTE.white;
  ctx.fillRect(2 + (f % 3), 1, 1, 1);

  ctx.restore();
}
