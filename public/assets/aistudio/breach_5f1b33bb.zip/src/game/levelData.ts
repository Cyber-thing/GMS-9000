import type { DoorColor, EnemyKind, PickupKind, PropKind } from './types';

export interface ElevatorDef {
  id: string;
  col: number;
  widthTiles: number;
  topRow: number;    // top surface aligns with topRow * TILE_SIZE
  bottomRow: number; // top surface aligns with bottomRow * TILE_SIZE
  speed: number;
}

export interface DoorDef {
  id: string;
  color: DoorColor;
  col: number;
  topRow: number;    // top open row (3 tiles tall: topRow..topRow+2)
  heightTiles: number;
  timedSeconds: number | null;
}

export interface ButtonDef {
  id: string;
  color: DoorColor;
  col: number;
  row: number; // standing row (terminal sits on row)
  label: string;
}

export interface EnemySpawnDef {
  kind: EnemyKind;
  col: number;
  row: number;
  facing: 1 | -1;
  patrolMinCol: number;
  patrolMaxCol: number;
}

export interface PropSpawnDef {
  kind: PropKind;
  col: number;
  row: number;
  drop?: PickupKind;
}

export interface PickupSpawnDef {
  kind: PickupKind;
  col: number;
  row: number;
}

export interface NeonSignDef {
  col: number;
  row: number;
  text: string;
  color: string;
}

export interface WindowZoneDef {
  col: number;
  row: number;
  wCols: number;
  hRows: number;
}

export interface SteamVentDef {
  col: number;
  row: number;
  dir: 'up' | 'down' | 'right';
}

// Legend for ASCII Tilemap (120 cols x 45 rows, 16px per tile => 1920 x 720 world)
// '#' = Solid Steel/Concrete Block
// '=' = One-way Metal Catwalk Platform
// '.' = Empty Air
//
// Note: Doors, Elevators, Terminals, Enemies, Props, Pickups are defined cleanly
// alongside the map so coordinates are exact and editable.

const ROWS = 45;
const COLS = 120;

function buildRawGrid(): string[] {
  const grid: string[][] = Array.from({ length: ROWS }, () => Array(COLS).fill('.'));

  const fillRect = (c0: number, r0: number, c1: number, r1: number, ch: string) => {
    for (let r = r0; r <= r1; r++) {
      for (let c = c0; c <= c1; c++) {
        if (r >= 0 && r < ROWS && c >= 0 && c < COLS) {
          grid[r][c] = ch;
        }
      }
    }
  };

  // Outer perimeter
  fillRect(0, 0, COLS - 1, 1, '#');        // Roof
  fillRect(0, ROWS - 3, COLS - 1, ROWS - 1, '#'); // Ground foundation (rows 42..44)
  fillRect(0, 0, 1, ROWS - 1, '#');        // Left outer wall
  fillRect(COLS - 2, 0, COLS - 1, ROWS - 1, '#'); // Right outer wall

  // =========================================================================
  // FLOOR 3 (Top Floor: rows 2..10, floor at row 11, divider at row 12)
  // =========================================================================
  fillRect(2, 11, 99, 12, '#');
  // Elevator B shaft open at cols 100..103!
  fillRect(104, 11, 117, 12, '#');

  // Extraction Bay divider wall above Green Door (col 26, rows 2..7 solid, rows 8..10 = Green Door)
  fillRect(26, 2, 26, 7, '#');

  // Floor 3 upper catwalk for Green Terminal (cols 56..70 at row 8, step at cols 72..76 row 10? Wait: row 9!)
  // Wait: Floor 3 standing floor is row 11 (feet at y = 176).
  // A one-way platform at row 9 has top at y = 144 (32px = 2 tiles up, super easy jump!).
  // A second platform at row 7 has top at y = 112 (32px up from row 9).
  fillRect(72, 9, 76, 9, '=');
  fillRect(54, 7, 69, 7, '=');
  fillRect(46, 9, 50, 9, '=');

  // =========================================================================
  // FLOOR 2 (Middle Floor: rows 13..22, floor at row 23, divider rows 24..25)
  // =========================================================================
  fillRect(2, 23, 15, 25, '#');
  // Elevator A shaft open at cols 16..19!
  fillRect(20, 23, 99, 25, '#');
  // Elevator B shaft recess at cols 100..103 (floor at row 24..25 so elevator top rests flush at row 23!)
  fillRect(100, 24, 103, 25, '#');
  fillRect(104, 23, 117, 25, '#');

  // Blue Door wall above Blue Door (col 94, rows 13..19 solid, rows 20..22 = Blue Door)
  fillRect(94, 13, 94, 19, '#');

  // Floor 2 West Server Vault platforms (left of Elevator A, cols 2..15)
  // Elevator A is at cols 16..19, so player exits LEFT to cols 2..15 or RIGHT to cols 20..93.
  // Actually let's put an upper Server Vault on the LEFT (cols 3..14) AND mid-platforms on the right!
  fillRect(11, 21, 14, 21, '='); // 2 tiles up from row 23
  fillRect(3, 19, 10, 19, '=');  // 2 tiles up from row 21 -> Blue Terminal sits here!

  // Floor 2 East-Center combat catwalks (cols 36..80)
  fillRect(36, 21, 42, 21, '=');
  fillRect(46, 19, 62, 19, '=');
  fillRect(66, 21, 74, 21, '=');

  // =========================================================================
  // FLOOR 1 (Bottom Floor: rows 26..41, floor at row 42)
  // =========================================================================
  // Raised Mezzanine Deck on Left (cols 2..20)
  // Left wall seals Elevator A vestibule on left (col 15, rows 26..36)
  fillRect(15, 26, 15, 36, '#');
  // Floor beneath Elevator A (col 16..19, row 37 solid so players can't jump up from underneath!)
  fillRect(16, 37, 19, 37, '#');
  // Right lip of Elevator A vestibule + Red Door wall (col 20 solid row 36, col 21 Red Door rows 33..35, solid rows 26..32)
  fillRect(20, 36, 23, 37, '#');
  fillRect(21, 26, 21, 32, '#');

  // Floor 1 Mezzanine Combat Bridge (cols 24..113 at row 36, with gaps/catwalks for dropping down or jumping up)
  // Solid floor for Red Door approach and Mezzanine east wing
  fillRect(24, 36, 38, 36, '#');
  fillRect(42, 36, 56, 36, '='); // One-way catwalk over lower loading bay
  fillRect(60, 36, 80, 36, '#');
  fillRect(84, 36, 98, 36, '='); // One-way catwalk
  fillRect(102, 36, 109, 36, '='); // One-way entry onto Red Terminal ledge
  fillRect(110, 36, 117, 36, '#'); // Red Terminal platform on far east!

  // Stepping one-way platforms from Floor 1 Ground (row 42) up to Mezzanine (row 36)
  // On the far right (cols 106..115):
  fillRect(111, 40, 116, 40, '='); // 2 tiles up from row 42
  fillRect(103, 38, 109, 38, '='); // 2 tiles up from row 40 -> jump to row 36 at col 102..117!
  // Also an optional mid-bay climb at cols 48..54 so player can jump up/down smoothly:
  fillRect(51, 40, 56, 40, '=');
  fillRect(43, 38, 49, 38, '=');

  // Lower Floor 1 decorative cover ledge (small 1-tile crates/step)
  fillRect(28, 41, 30, 41, '#');
  fillRect(72, 41, 74, 41, '#');

  return grid.map((row) => row.join(''));
}

export const LEVEL_ASCII: string[] = buildRawGrid();

export const LEVEL_SPAWN = {
  col: 4,
  row: 42, // feet rest on top of row 42
};

export const LEVEL_CHECKPOINT = {
  col: 23,
  row: 23, // Floor 2 right beside Elevator A
};

export const LEVEL_EXIT = {
  col: 8,
  row: 11, // Floor 3 Extraction Bay
};

export const ELEVATOR_DEFS: ElevatorDef[] = [
  {
    id: 'elev-a',
    col: 16,
    widthTiles: 4,
    topRow: 23,
    bottomRow: 36,
    speed: 95,
  },
  {
    id: 'elev-b',
    col: 100,
    widthTiles: 4,
    topRow: 11,
    bottomRow: 23,
    speed: 105,
  },
];

export const DOOR_DEFS: DoorDef[] = [
  {
    id: 'door-red',
    color: 'red',
    col: 21,
    topRow: 33,
    heightTiles: 3,
    timedSeconds: null,
  },
  {
    id: 'door-blue',
    color: 'blue',
    col: 94,
    topRow: 20,
    heightTiles: 3,
    timedSeconds: null,
  },
  {
    id: 'door-green',
    color: 'green',
    col: 26,
    topRow: 8,
    heightTiles: 3,
    timedSeconds: 15, // Closes after 15 seconds!
  },
];

export const BUTTON_DEFS: ButtonDef[] = [
  {
    id: 'btn-red',
    color: 'red',
    col: 113,
    row: 36,
    label: 'RED GATE',
  },
  {
    id: 'btn-blue',
    color: 'blue',
    col: 6,
    row: 19,
    label: 'BLUE GATE',
  },
  {
    id: 'btn-green',
    color: 'green',
    col: 61,
    row: 7,
    label: 'EXIT LOCK (15S)',
  },
];

export const ENEMY_SPAWNS: EnemySpawnDef[] = [
  // Floor 1 Ground
  { kind: 'thug', col: 26, row: 42, facing: -1, patrolMinCol: 22, patrolMaxCol: 33 },
  { kind: 'thug', col: 44, row: 42, facing: -1, patrolMinCol: 34, patrolMaxCol: 54 },
  { kind: 'heavy', col: 68, row: 42, facing: -1, patrolMinCol: 60, patrolMaxCol: 78 },
  { kind: 'thug', col: 92, row: 42, facing: -1, patrolMinCol: 82, patrolMaxCol: 104 },

  // Floor 1 Mezzanine (on way to Red Terminal & return)
  { kind: 'turret', col: 96, row: 26, facing: -1, patrolMinCol: 96, patrolMaxCol: 96 },
  { kind: 'heavy', col: 72, row: 36, facing: 1, patrolMinCol: 61, patrolMaxCol: 79 },
  { kind: 'thug', col: 33, row: 36, facing: 1, patrolMinCol: 25, patrolMaxCol: 37 },
  { kind: 'drone', col: 52, row: 31, facing: -1, patrolMinCol: 42, patrolMaxCol: 62 },

  // Floor 2 Server Farm (Left Vault for Blue Terminal + East Corridor to Blue Door)
  { kind: 'thug', col: 8, row: 19, facing: 1, patrolMinCol: 4, patrolMaxCol: 10 },
  { kind: 'drone', col: 30, row: 17, facing: -1, patrolMinCol: 22, patrolMaxCol: 40 },
  { kind: 'heavy', col: 54, row: 23, facing: -1, patrolMinCol: 44, patrolMaxCol: 66 },
  { kind: 'thug', col: 53, row: 19, facing: -1, patrolMinCol: 47, patrolMaxCol: 61 },
  { kind: 'turret', col: 76, row: 13, facing: -1, patrolMinCol: 76, patrolMaxCol: 76 },
  { kind: 'heavy', col: 86, row: 23, facing: -1, patrolMinCol: 76, patrolMaxCol: 92 },

  // Floor 3 Executive Security Deck
  { kind: 'thug', col: 88, row: 11, facing: 1, patrolMinCol: 78, patrolMaxCol: 96 },
  { kind: 'turret', col: 72, row: 2, facing: 1, patrolMinCol: 72, patrolMaxCol: 72 },
  { kind: 'drone', col: 62, row: 5, facing: 1, patrolMinCol: 50, patrolMaxCol: 74 },
  { kind: 'heavy', col: 44, row: 11, facing: 1, patrolMinCol: 33, patrolMaxCol: 55 },
  { kind: 'thug', col: 34, row: 11, facing: 1, patrolMinCol: 28, patrolMaxCol: 42 },
];

export const PROP_SPAWNS: PropSpawnDef[] = [
  // Floor 1
  { kind: 'crate', col: 11, row: 42, drop: 'ammo' },
  { kind: 'barrel', col: 38, row: 42 },
  { kind: 'monitor', col: 58, row: 42 },
  { kind: 'barrel', col: 64, row: 42 },
  { kind: 'crate', col: 82, row: 42, drop: 'health' },
  { kind: 'monitor', col: 106, row: 36 },
  { kind: 'barrel', col: 66, row: 36 },

  // Floor 2
  { kind: 'monitor', col: 12, row: 23 },
  { kind: 'crate', col: 34, row: 23, drop: 'ammo' },
  { kind: 'barrel', col: 49, row: 23 },
  { kind: 'monitor', col: 62, row: 19 },
  { kind: 'barrel', col: 82, row: 23 },
  { kind: 'crate', col: 110, row: 23, drop: 'health' },

  // Floor 3
  { kind: 'crate', col: 110, row: 11, drop: 'ammo' },
  { kind: 'barrel', col: 82, row: 11 },
  { kind: 'monitor', col: 65, row: 7 },
  { kind: 'barrel', col: 40, row: 11 },
  { kind: 'crate', col: 20, row: 11, drop: 'health' },
];

export const PICKUP_SPAWNS: PickupSpawnDef[] = [
  { kind: 'shotgun', col: 60, row: 42 },
  { kind: 'health', col: 98, row: 42 },
  { kind: 'smg', col: 8, row: 23 },
  { kind: 'ammo', col: 55, row: 19 },
  { kind: 'health', col: 108, row: 11 },
  { kind: 'ammo', col: 78, row: 11 },
];

export const WINDOW_ZONES: WindowZoneDef[] = [
  // Floor 1 windows
  { col: 28, row: 29, wCols: 14, hRows: 6 },
  { col: 72, row: 29, wCols: 16, hRows: 6 },
  // Floor 2 windows
  { col: 28, row: 15, wCols: 18, hRows: 6 },
  { col: 64, row: 15, wCols: 18, hRows: 6 },
  // Floor 3 windows
  { col: 6, row: 4, wCols: 14, hRows: 5 },
  { col: 36, row: 4, wCols: 18, hRows: 5 },
  { col: 78, row: 4, wCols: 16, hRows: 5 },
];

export const NEON_SIGNS: NeonSignDef[] = [
  { col: 4, row: 38, text: 'INTERCELL SYNTETICS', color: '#00f0ff' },
  { col: 46, row: 31, text: 'INTERCELL LAB', color: '#ff2a85' },
  { col: 105, row: 32, text: 'OVERRIDE', color: '#ff2b45' },
  { col: 27, row: 17, text: 'BIO-VAULT', color: '#39ff14' },
  { col: 83, row: 16, text: 'ELEV B', color: '#00d4ff' },
  { col: 84, row: 5, text: 'SYNTETICS HQ', color: '#ff9500' },
  { col: 11, row: 5, text: 'EXIT BAY', color: '#39ff14' },
];

export const STEAM_VENTS: SteamVentDef[] = [
  { col: 9, row: 37, dir: 'down' },
  { col: 57, row: 42, dir: 'up' },
  { col: 38, row: 23, dir: 'up' },
  { col: 84, row: 13, dir: 'down' },
  { col: 48, row: 11, dir: 'up' },
];
