import React, { useEffect, useRef, useState } from 'react';
import { WEAPONS } from './game/config';
import { GameEngine } from './game/engine';
import type { DoorColor, HudSnapshot, WeaponId } from './game/types';

function formatTime(sec: number): string {
  const whole = Math.max(0, Math.floor(sec));
  const m = Math.floor(whole / 60);
  const s = whole % 60;
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

const DOOR_HEX: Record<DoorColor, string> = {
  red: '#ff2b45',
  blue: '#00d4ff',
  green: '#39ff14',
};

function WeaponIcon({ weapon }: { weapon: WeaponId }) {
  if (weapon === 'shotgun') {
    return (
      <svg viewBox="0 0 24 24" className="w-5 h-5" aria-hidden="true">
        <path d="M2 12h18v3H11l-2 4H6l1-4H2v-3z" fill="#ff9500" stroke="#070811" strokeWidth="1.2" />
        <rect x="6" y="10" width="9" height="2" fill="#ffe600" />
      </svg>
    );
  }
  if (weapon === 'smg') {
    return (
      <svg viewBox="0 0 24 24" className="w-5 h-5" aria-hidden="true">
        <path d="M3 10h16v3h-4v6h-3v-6H8l-2 5H3v-8z" fill="#00f0ff" stroke="#070811" strokeWidth="1.2" />
        <rect x="19" y="10" width="3" height="2" fill="#f8fafc" />
      </svg>
    );
  }
  return (
    <svg viewBox="0 0 24 24" className="w-5 h-5" aria-hidden="true">
      <path d="M5 9h14v3h-7l-2 7H6l1-7H5V9z" fill="#ffe600" stroke="#070811" strokeWidth="1.2" />
    </svg>
  );
}

function TitleEmblem() {
  return (
    <svg
      viewBox="0 0 480 120"
      className="w-full max-w-[480px] h-auto"
      role="img"
      aria-label="Intercell Syntetics"
    >
      <defs>
        <linearGradient id="nvBlade" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="#00f0ff" />
          <stop offset="50%" stopColor="#ff2a85" />
          <stop offset="100%" stopColor="#ff9500" />
        </linearGradient>
      </defs>
      {/* Structural angular backing frame */}
      <polygon
        points="6,14 462,14 474,28 474,98 456,112 18,112 6,98"
        fill="#090b16"
        fillOpacity="0.92"
        stroke="#00f0ff"
        strokeWidth="2"
      />
      <polygon points="12,20 456,20 466,30 466,34 12,34" fill="#171b36" />
      <rect x="16" y="24" width="66" height="5" fill="#00f0ff" />
      <rect x="88" y="24" width="24" height="5" fill="#ff2a85" />
      <text
        x="240"
        y="70"
        textAnchor="middle"
        fill="url(#nvBlade)"
        stroke="#05060c"
        strokeWidth="4"
        paintOrder="stroke fill"
        style={{
          fontFamily: '"Chakra Petch", sans-serif',
          fontWeight: 700,
          fontSize: '33px',
          letterSpacing: '0.07em',
        }}
      >
        INTERCELL SYNTETICS
      </text>
      <text
        x="240"
        y="98"
        textAnchor="middle"
        fill="#00f0ff"
        style={{
          fontFamily: '"JetBrains Mono", monospace',
          fontWeight: 700,
          fontSize: '12px',
          letterSpacing: '0.26em',
        }}
      >
        CYBERNETIC BUNKER BREACH
      </text>
    </svg>
  );
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const engineRef = useRef<GameEngine | null>(null);
  const [hud, setHud] = useState<HudSnapshot | null>(null);

  useEffect(() => {
    const engine = new GameEngine((snapshot) => {
      setHud(snapshot);
    });
    engineRef.current = engine;

    let cleanup: (() => void) | undefined;
    if (canvasRef.current) {
      cleanup = engine.mount(canvasRef.current);
    }

    const params = new URLSearchParams(window.location.search);
    if (params.get('autostart') === '1') {
      engine.startNewRun();
    } else {
      engine.setPhase('title');
    }

    return () => {
      cleanup?.();
      engineRef.current = null;
    };
  }, []);

  // Enter / Space on Title screen starts the game
  useEffect(() => {
    const onTitleKey = (e: KeyboardEvent) => {
      const eng = engineRef.current;
      if (!eng) return;
      if (eng.phase === 'title' && (e.code === 'Enter' || e.code === 'Space')) {
        e.preventDefault();
        eng.startNewRun();
      }
    };
    window.addEventListener('keydown', onTitleKey);
    return () => window.removeEventListener('keydown', onTitleKey);
  }, []);

  const handleStart = (e?: React.MouseEvent<HTMLButtonElement>) => {
    e?.currentTarget.blur();
    engineRef.current?.startNewRun();
  };

  const handleRespawn = (e?: React.MouseEvent<HTMLButtonElement>) => {
    e?.currentTarget.blur();
    engineRef.current?.respawnAtCheckpoint();
  };

  const handleResume = (e?: React.MouseEvent<HTMLButtonElement>) => {
    e?.currentTarget.blur();
    engineRef.current?.setPhase('playing');
  };

  const handleTitle = (e?: React.MouseEvent<HTMLButtonElement>) => {
    e?.currentTarget.blur();
    engineRef.current?.setPhase('title');
  };

  const handleMute = (e: React.MouseEvent<HTMLButtonElement>) => {
    e.currentTarget.blur();
    engineRef.current?.toggleMute();
  };

  const handleCrt = (e: React.MouseEvent<HTMLButtonElement>) => {
    e.currentTarget.blur();
    engineRef.current?.toggleCrt();
  };

  const handlePause = (e: React.MouseEvent<HTMLButtonElement>) => {
    e.currentTarget.blur();
    const eng = engineRef.current;
    if (!eng) return;
    if (eng.phase === 'playing') eng.setPhase('paused');
    else if (eng.phase === 'paused') eng.setPhase('playing');
  };

  const phase = hud?.phase ?? 'title';
  const weaponCfg = hud ? WEAPONS[hud.weapon] : WEAPONS.pistol;

  return (
    <main className="relative w-screen h-screen bg-[#070811] flex items-center justify-center overflow-hidden">
      {/* Pixel-Art Game Canvas */}
      <div className="relative w-full h-full flex items-center justify-center">
        <canvas
          ref={canvasRef}
          data-testid="game-canvas"
          className="pixel-canvas w-full h-full object-contain max-w-full max-h-full block bg-[#070811]"
        />
      </div>

      {/* ===================================================================
          TITLE SCREEN OVERLAY
      ==================================================================== */}
      {phase === 'title' && (
        <div
          className="fixed inset-0 flex flex-col justify-between p-6 md:p-10 pointer-events-none"
          style={{
            background:
              'linear-gradient(90deg, rgba(7,8,17,0.92) 0%, rgba(7,8,17,0.72) 48%, rgba(7,8,17,0.22) 100%)',
          }}
        >
          <div className="flex justify-end gap-2 pointer-events-auto">
            <button
              type="button"
              onClick={handleMute}
              aria-label={hud?.muted ? 'Unmute audio' : 'Mute audio'}
              className="px-3 py-1.5 text-xs font-mono-hud uppercase tracking-wider bg-[#0d1021]/90 border border-[#2e3659] text-slate-200 hover:border-[#00f0ff] hover:text-[#00f0ff] transition-colors cursor-pointer"
            >
              {hud?.muted ? 'Sound: Off [M]' : 'Sound: On [M]'}
            </button>
            <button
              type="button"
              onClick={handleCrt}
              aria-label={hud?.crtEnabled ? 'Disable CRT scanlines' : 'Enable CRT scanlines'}
              className="px-3 py-1.5 text-xs font-mono-hud uppercase tracking-wider bg-[#0d1021]/90 border border-[#2e3659] text-slate-200 hover:border-[#00f0ff] hover:text-[#00f0ff] transition-colors cursor-pointer"
            >
              {hud?.crtEnabled ? 'CRT: On [C]' : 'CRT: Off [C]'}
            </button>
          </div>

          <div className="max-w-lg flex flex-col items-start gap-6 my-auto pointer-events-auto">
            <TitleEmblem />
            <p className="text-slate-200 text-base md:text-lg leading-relaxed max-w-md font-medium">
              Infiltrate the three-floor Intercell Syntetics bunker. Unlock the Red, Blue, and timed Green security gates, ride the cargo elevators, and reach the roof extraction airlock.
            </p>
            <div className="flex items-center gap-4">
              <button
                type="button"
                data-start="true"
                onClick={handleStart}
                className="px-7 py-3.5 text-base font-bold uppercase tracking-widest bg-[#ff2a85] text-white border-2 border-[#ffe600] shadow-[4px_4px_0px_#00f0ff] hover:bg-[#ff4294] active:translate-x-0.5 active:translate-y-0.5 transition-transform cursor-pointer whitespace-nowrap"
              >
                Start Mission
              </button>
              <span className="text-xs font-mono-hud text-slate-400 uppercase tracking-wider">
                Press Enter or Space
              </span>
            </div>
          </div>

          <div className="text-xs font-mono-hud text-slate-300 tracking-wide">
            A/D or Arrows Move · Space Jump · S/Down Crouch · W/Up Aim Up/Angle · Ctrl Shoot · Shift Dash · E Interact · P Pause
          </div>
        </div>
      )}

      {/* ===================================================================
          ACTIVE GAMEPLAY HUD
      ==================================================================== */}
      {phase === 'playing' && hud && (
        <div className="fixed inset-0 pointer-events-none flex flex-col justify-between p-3 md:p-4">
          {/* Top Perimeter Row */}
          <div className="flex items-start justify-between gap-4">
            {/* Top-Left Cluster: Health Pips + Weapon + Floor */}
            <div className="flex flex-col gap-2 pointer-events-auto">
              <div className="flex items-center gap-3 bg-[#070811]/90 border border-[#2e3659] px-3 py-2 shadow-[2px_2px_0px_#000]">
                <div className="flex flex-col">
                  <span className="text-[10px] font-mono-hud uppercase tracking-widest text-slate-400">
                    Armor HP
                  </span>
                  <div className="flex items-center gap-1 mt-0.5" aria-label={`Health ${hud.hp} of ${hud.maxHp}`}>
                    {Array.from({ length: hud.maxHp }).map((_, idx) => {
                      const filled = idx < hud.hp;
                      return (
                        <svg key={idx} viewBox="0 0 14 14" className="w-4 h-4" aria-hidden="true">
                          <polygon
                            points="2,1 12,1 13,5 11,13 3,13 1,5"
                            fill={filled ? (hud.hp <= 2 ? '#ff2b45' : '#39ff14') : '#151932'}
                            stroke={filled ? '#f8fafc' : '#3b4266'}
                            strokeWidth="1.2"
                          />
                        </svg>
                      );
                    })}
                  </div>
                </div>

                <div className="h-7 w-px bg-[#2e3659]" />

                {/* Active Weapon Readout */}
                <div className="flex items-center gap-2">
                  <WeaponIcon weapon={hud.weapon} />
                  <div className="flex flex-col leading-none">
                    <span className="text-[10px] font-mono-hud uppercase tracking-wider text-slate-400">
                      {weaponCfg.shortName}
                    </span>
                    <span className="text-lg font-mono-hud font-bold text-[#ffe600] leading-tight">
                      {hud.ammo[hud.weapon] === Infinity ? 'INF' : hud.ammo[hud.weapon]}
                    </span>
                  </div>
                </div>

                <div className="h-7 w-px bg-[#2e3659]" />

                <div className="flex flex-col leading-none">
                  <span className="text-[10px] font-mono-hud uppercase tracking-wider text-slate-400">
                    Deck
                  </span>
                  <span className="text-lg font-mono-hud font-bold text-[#00f0ff] leading-tight">
                    F{hud.floorNumber}
                  </span>
                </div>
              </div>

              {/* Unlocked Weapon Quick-Switch Strip */}
              {hud.unlockedWeapons.length > 1 && (
                <div className="flex items-center gap-1.5">
                  {hud.unlockedWeapons.map((wid, i) => {
                    const active = hud.weapon === wid;
                    return (
                      <button
                        key={wid}
                        type="button"
                        tabIndex={-1}
                        onClick={(e) => {
                          e.currentTarget.blur();
                          engineRef.current?.player.selectWeapon(wid);
                        }}
                        className={`px-2 py-1 text-[11px] font-mono-hud uppercase border transition-colors cursor-pointer ${
                          active
                            ? 'bg-[#171d38] border-[#ffe600] text-[#ffe600]'
                            : 'bg-[#070811]/85 border-[#2e3659] text-slate-400 hover:text-slate-100'
                        }`}
                      >
                        [{i + 1}] {WEAPONS[wid].shortName}
                      </button>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Top-Center Transient Objective Banner */}
            {hud.bannerText && (
              <div className="hidden sm:flex items-center bg-[#070811]/95 border border-[#00f0ff] px-4 py-1.5 shadow-[3px_3px_0px_#ff2a85]">
                <span className="text-xs font-mono-hud font-bold uppercase tracking-widest text-[#f8fafc]">
                  {hud.bannerText}
                </span>
              </div>
            )}

            {/* Top-Right Cluster: Security Doors + Timer/Kills + Utility Buttons */}
            <div className="flex items-start gap-2 pointer-events-auto">
              <div className="flex items-center gap-3 bg-[#070811]/90 border border-[#2e3659] px-3 py-2 shadow-[2px_2px_0px_#000]">
                {/* Color-coded Security Doors */}
                <div className="flex items-center gap-2">
                  {hud.doors.map((d) => {
                    const hex = DOOR_HEX[d.color];
                    const statusLabel = d.timerRemaining !== null
                      ? `${Math.ceil(d.timerRemaining)}S`
                      : d.isOpen
                        ? 'OPEN'
                        : 'LOCK';
                    return (
                      <div key={d.color} className="flex flex-col items-center leading-none">
                        <span
                          className="text-[9px] font-mono-hud font-bold uppercase"
                          style={{ color: hex }}
                        >
                          {d.color}
                        </span>
                        <span
                          className={`text-[11px] font-mono-hud font-bold mt-0.5 ${
                            d.isOpen ? 'text-[#39ff14]' : 'text-slate-400'
                          }`}
                        >
                          {statusLabel}
                        </span>
                      </div>
                    );
                  })}
                </div>

                <div className="h-7 w-px bg-[#2e3659]" />

                {/* Kills & Elapsed Time */}
                <div className="flex items-center gap-3">
                  <div className="flex flex-col leading-none">
                    <span className="text-[10px] font-mono-hud uppercase text-slate-400">Kills</span>
                    <span className="text-base font-mono-hud font-bold text-slate-100">
                      {hud.kills}/{hud.totalEnemies}
                    </span>
                  </div>
                  <div className="flex flex-col leading-none">
                    <span className="text-[10px] font-mono-hud uppercase text-slate-400">Time</span>
                    <span className="text-base font-mono-hud font-bold text-[#00f0ff]">
                      {formatTime(hud.elapsedTime)}
                    </span>
                  </div>
                </div>
              </div>

              {/* Square Icon Utility Buttons */}
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  tabIndex={-1}
                  onClick={handleMute}
                  aria-label={hud.muted ? 'Unmute audio (M)' : 'Mute audio (M)'}
                  title="Toggle Mute [M]"
                  className="w-9 h-9 flex items-center justify-center bg-[#070811]/90 border border-[#2e3659] text-slate-200 hover:border-[#00f0ff] hover:text-[#00f0ff] cursor-pointer"
                >
                  <svg viewBox="0 0 24 24" className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2">
                    <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5" fill="currentColor" />
                    {hud.muted ? (
                      <path d="M22 9l-6 6M16 9l6 6" stroke="#ff2b45" />
                    ) : (
                      <path d="M15.5 8.5a5 5 0 010 7M18.5 5.5a9 9 0 010 13" />
                    )}
                  </svg>
                </button>
                <button
                  type="button"
                  tabIndex={-1}
                  onClick={handleCrt}
                  aria-label="Toggle CRT scanlines (C)"
                  title="Toggle CRT [C]"
                  className={`w-9 h-9 flex items-center justify-center bg-[#070811]/90 border text-xs font-mono-hud font-bold cursor-pointer ${
                    hud.crtEnabled
                      ? 'border-[#00f0ff] text-[#00f0ff]'
                      : 'border-[#2e3659] text-slate-400 hover:text-slate-100'
                  }`}
                >
                  CRT
                </button>
                <button
                  type="button"
                  tabIndex={-1}
                  onClick={handlePause}
                  aria-label="Pause game (P)"
                  title="Pause [P / Esc]"
                  className="w-9 h-9 flex items-center justify-center bg-[#070811]/90 border border-[#2e3659] text-slate-200 hover:border-[#ff2a85] hover:text-[#ff2a85] cursor-pointer"
                >
                  <svg viewBox="0 0 24 24" className="w-4 h-4" fill="currentColor">
                    <rect x="6" y="5" width="4" height="14" />
                    <rect x="14" y="5" width="4" height="14" />
                  </svg>
                </button>
              </div>
            </div>
          </div>

          {/* Bottom Safe Margin Control Reminder */}
          <div className="flex items-end justify-between text-[11px] font-mono-hud text-slate-300/90">
            <span className="bg-[#070811]/80 px-2.5 py-1 border border-[#1e2440]">
              A/D Move · Space Jump · S Crouch · W/Up Aim Up/Angle · Ctrl Shoot · Shift Dash · E Interact
            </span>
            {hud.checkpointSaved && (
              <span className="bg-[#070811]/80 px-2.5 py-1 border border-[#39ff14]/60 text-[#39ff14]">
                CHECKPOINT SAVED
              </span>
            )}
          </div>
        </div>
      )}

      {/* ===================================================================
          PAUSE MODAL
      ==================================================================== */}
      {phase === 'paused' && hud && (
        <div className="fixed inset-0 bg-[#070811]/80 flex items-center justify-center p-4">
          <div className="w-full max-w-sm bg-[#0d1021] border-2 border-[#00f0ff] shadow-[6px_6px_0px_#ff2a85] p-6 flex flex-col gap-5">
            <div>
              <p className="text-xs font-mono-hud uppercase tracking-widest text-[#00f0ff]">
                Simulation Halted
              </p>
              <h2 className="text-2xl font-bold uppercase tracking-wider text-white mt-1">
                Mission Paused
              </h2>
            </div>

            <div className="grid grid-cols-2 gap-3 text-sm font-mono-hud border-y border-[#252a45] py-3">
              <div>
                <span className="text-slate-400 text-xs block">Elapsed</span>
                <span className="text-white font-bold">{formatTime(hud.elapsedTime)}</span>
              </div>
              <div>
                <span className="text-slate-400 text-xs block">Hostiles Down</span>
                <span className="text-white font-bold">
                  {hud.kills}/{hud.totalEnemies}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-2.5">
              <button
                type="button"
                onClick={handleResume}
                className="w-full py-2.5 px-4 font-bold uppercase tracking-wider bg-[#00f0ff] text-[#070811] hover:bg-[#5ef7ff] cursor-pointer"
              >
                Resume Mission
              </button>
              <button
                type="button"
                onClick={handleStart}
                className="w-full py-2.5 px-4 font-bold uppercase tracking-wider bg-[#161a33] text-slate-100 border border-[#3b4266] hover:border-[#ff2a85] cursor-pointer"
              >
                Restart Level
              </button>
              <button
                type="button"
                onClick={handleTitle}
                className="w-full py-2.5 px-4 font-bold uppercase tracking-wider bg-transparent text-slate-400 border border-[#252a45] hover:text-white cursor-pointer"
              >
                Return to Title
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ===================================================================
          VICTORY MODAL ("MISSION COMPLETE")
      ==================================================================== */}
      {phase === 'victory' && hud && (
        <div className="fixed inset-0 bg-[#070811]/85 flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-[#0d1021] border-2 border-[#39ff14] shadow-[6px_6px_0px_#00f0ff] p-7 flex flex-col gap-5">
            <div>
              <p className="text-xs font-mono-hud uppercase tracking-widest text-[#39ff14]">
                Extraction Confirmed
              </p>
              <h2 className="text-3xl font-bold uppercase tracking-wider text-white mt-1">
                Mission Complete
              </h2>
            </div>

            <div className="grid grid-cols-2 gap-4 bg-[#070811] border border-[#252a45] p-4 font-mono-hud">
              <div>
                <span className="text-[11px] uppercase text-slate-400 block">Clear Time</span>
                <span className="text-2xl font-bold text-[#00f0ff]">
                  {formatTime(hud.elapsedTime)}
                </span>
              </div>
              <div>
                <span className="text-[11px] uppercase text-slate-400 block">Hostiles Killed</span>
                <span className="text-2xl font-bold text-[#ff2a85]">
                  {hud.kills}/{hud.totalEnemies}
                </span>
              </div>
              <div>
                <span className="text-[11px] uppercase text-slate-400 block">Props Wrecked</span>
                <span className="text-xl font-bold text-[#ffe600]">{hud.propsDestroyed}</span>
              </div>
              <div>
                <span className="text-[11px] uppercase text-slate-400 block">Damage Taken</span>
                <span className="text-xl font-bold text-slate-200">{hud.damageTaken} HP</span>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-3">
              <button
                type="button"
                data-start="true"
                onClick={handleStart}
                className="flex-1 py-3 px-5 font-bold uppercase tracking-wider bg-[#39ff14] text-[#070811] hover:bg-[#6dff54] cursor-pointer"
              >
                Play Again
              </button>
              <button
                type="button"
                onClick={handleTitle}
                className="py-3 px-5 font-bold uppercase tracking-wider bg-[#161a33] text-slate-200 border border-[#3b4266] hover:border-[#00f0ff] cursor-pointer"
              >
                Title Screen
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ===================================================================
          DEFEAT MODAL ("OPERATIVE DOWN")
      ==================================================================== */}
      {phase === 'defeat' && hud && (
        <div className="fixed inset-0 bg-[#070811]/85 flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-[#0d1021] border-2 border-[#ff2b45] shadow-[6px_6px_0px_#ff9500] p-7 flex flex-col gap-5">
            <div>
              <p className="text-xs font-mono-hud uppercase tracking-widest text-[#ff2b45]">
                Vital Signs Flatlined
              </p>
              <h2 className="text-3xl font-bold uppercase tracking-wider text-white mt-1">
                Operative Down
              </h2>
            </div>

            <div className="grid grid-cols-3 gap-3 bg-[#070811] border border-[#252a45] p-4 font-mono-hud">
              <div>
                <span className="text-[11px] uppercase text-slate-400 block">Deck</span>
                <span className="text-xl font-bold text-[#00f0ff]">F{hud.floorNumber}</span>
              </div>
              <div>
                <span className="text-[11px] uppercase text-slate-400 block">Kills</span>
                <span className="text-xl font-bold text-[#ff2a85]">
                  {hud.kills}/{hud.totalEnemies}
                </span>
              </div>
              <div>
                <span className="text-[11px] uppercase text-slate-400 block">Time</span>
                <span className="text-xl font-bold text-slate-200">
                  {formatTime(hud.elapsedTime)}
                </span>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-3">
              {hud.checkpointSaved ? (
                <>
                  <button
                    type="button"
                    data-start="true"
                    onClick={handleRespawn}
                    className="flex-1 py-3 px-5 font-bold uppercase tracking-wider bg-[#00f0ff] text-[#070811] hover:bg-[#5ef7ff] cursor-pointer"
                  >
                    Respawn Checkpoint
                  </button>
                  <button
                    type="button"
                    onClick={handleStart}
                    className="py-3 px-4 font-bold uppercase tracking-wider bg-[#161a33] text-slate-200 border border-[#3b4266] hover:border-[#ff2b45] cursor-pointer"
                  >
                    Restart All
                  </button>
                </>
              ) : (
                <button
                  type="button"
                  data-start="true"
                  onClick={handleStart}
                  className="flex-1 py-3 px-5 font-bold uppercase tracking-wider bg-[#ff2b45] text-white hover:bg-[#ff4d63] cursor-pointer"
                >
                  Restart Mission
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </main>
  );
}
